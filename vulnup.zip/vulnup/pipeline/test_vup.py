"""Check CDK and the whole-project ILP against brute force on random small instances."""
import itertools, random, sys, os
sys.path.insert(0, os.path.dirname(__file__))
import vup

def random_instance(rng, n_deps, n_adv):
    advs = [f'A{k}' for k in range(n_adv)]
    deps = []
    for j in range(n_deps):
        opts = []
        cur = set(rng.sample(advs, rng.randint(0, min(4, n_adv))))
        for k in range(rng.randint(1, 4)):
            if k:   # newer options tend to drop advisories, sometimes add one
                cur = {u for u in cur if rng.random() < 0.5}
                if rng.random() < 0.2:
                    cur.add(rng.choice(advs))
            cost = 0 if k == 0 else rng.choice([1, 1, 4, 7])
            opts.append((cost, frozenset(cur), {'d_major': 0, 'd_minor': k}))
        deps.append((f'd{j}', opts))
    w = {u: rng.random() for u in advs}
    return deps, w

def brute(deps, w, B):
    best = (float('inf'), None)
    for x in itertools.product(*[range(len(o)) for _, o in deps]):
        if vup.cost_of(deps, x) <= B:
            r = vup.risk_of(deps, w, x)
            if r < best[0] - 1e-12:
                best = (r, x)
    return best[0]

if __name__ == '__main__':
    rng = random.Random(7)
    bad = 0; n = 0
    for trial in range(300):
        deps, w = random_instance(rng, rng.randint(1, 6), rng.randint(1, 8))
        for B in (0, 1, 3, 5, 10):
            opt = brute(deps, w, B)
            x, _ = vup.solve_cdk(deps, w, B)
            xi, _ = vup.exact_ilp(deps, w, B)
            n += 1
            ok = (vup.cost_of(deps, x) <= B and abs(vup.risk_of(deps, w, x) - opt) < 1e-9 and
                  vup.cost_of(deps, xi) <= B and abs(vup.risk_of(deps, w, xi) - opt) < 1e-4 * max(1, opt))
            if not ok:
                bad += 1
                print('MISMATCH', trial, B, opt, vup.risk_of(deps, w, x), vup.risk_of(deps, w, xi))
    # force the ILP path inside CDK on a few instances
    vup.ENUM_LIMIT = 1
    for trial in range(60):
        deps, w = random_instance(rng, rng.randint(2, 5), rng.randint(2, 6))
        for B in (2, 6):
            opt = brute(deps, w, B); x, _ = vup.solve_cdk(deps, w, B); n += 1
            if abs(vup.risk_of(deps, w, x) - opt) > 1e-4 * max(1, opt) or vup.cost_of(deps, x) > B:
                bad += 1; print('MISMATCH (ILP path)', trial, B, opt, vup.risk_of(deps, w, x))
    print(f'{n} checks, {bad} mismatches')
