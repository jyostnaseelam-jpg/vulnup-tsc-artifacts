#!/bin/sh
# Extra experiments for the extended paper. Log: data/extra_runs.log
export EPSS_DATE=2024-01-01
echo "== single-service sensitivity"
for cfg in "0.1 1 3" "0 1 3" "1 1 3" "0.1 0 3" "0.1 1 1" "0.1 1 5"; do
  set -- $cfg
  COST_MAJOR=$3 python3 pipeline/run_eval.py 2024-01-01 $1 $2 > /dev/null 2>&1 && echo "done single d=$1 epss=$2 g=$3"
done
echo "== fleet learning-cost sweep (stack-similar, n=25)"
export TL_FULL=120 TL_MYOPIC=8
for L in 0 1 15; do for S in 1 2 3 4 5; do
  f=results/2024-01-01/fleet_epss2024-01-01/clustered_L${L}_n25_s${S}_T4.csv; [ -f $f ] && continue
  FLEET=clustered L=$L python3 pipeline/run_fleet.py 2024-01-01 25 $S 4 2>&1 | tail -1 | cut -c1-120
done; done
echo "== scalability (stack-similar, L=3)"
export TL_FULL=600
for N in 100 200; do for S in 1 2 3; do
  f=results/2024-01-01/fleet_epss2024-01-01/clustered_L3_n${N}_s${S}_T4.csv; [ -f $f ] && continue
  FLEET=clustered L=3 python3 pipeline/run_fleet.py 2024-01-01 $N $S 4 2>&1 | tail -3 | cut -c1-160
done; done
echo EXTRA_DONE
