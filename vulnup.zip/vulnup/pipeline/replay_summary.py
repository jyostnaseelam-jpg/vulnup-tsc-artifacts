"""Summarize final replays: cumulative exposure reduction per method, paired tests against VulnUp."""
import csv, glob, sys, statistics as st
from collections import defaultdict
from scipy.stats import wilcoxon

pat = sys.argv[1] if len(sys.argv) > 1 else 'results/replay/*_n25_*_b0.25.csv'
MAIN = 'VulnUp-Fleet (look-ahead 3)'
runs = []
for f in sorted(glob.glob(pat)):
    tot, src, over = defaultdict(float), set(), 0
    for r in csv.DictReader(open(f)):
        tot[r['method']] += float(r['exposure']); src.add(r['epss_source']); over += r['over_budget'] == 'True'
    ref = tot['Refresh only']
    runs.append({'file': f.split('/')[-1], 'mode': f.split('/')[-1].split('_')[0], 'over': over, 'src': src,
                 'red': {m: (ref - v) / ref for m, v in tot.items()}})
methods = list(runs[0]['red'])
print(f"{len(runs)} replays; over-budget months: {sum(r['over'] for r in runs)}; look-ahead EPSS used: "
      f"{any('look-ahead' in s for r in runs for s in r['src'])}")
for mode in ('clustered', 'random', 'all'):
    sel = [r for r in runs if mode == 'all' or r['mode'] == mode]
    if not sel:
        continue
    print(f'\n== {mode} ({len(sel)} fleets)')
    for m in methods:
        v = [r['red'][m] for r in sel]
        print(f'   {m:30s} mean {st.mean(v):6.1%}  min {min(v):6.1%}  max {max(v):6.1%}')
    for m in methods:
        if m in (MAIN, 'Refresh only'):
            continue
        d = [r['red'][MAIN] - r['red'][m] for r in sel]
        nz = [x for x in d if abs(x) > 1e-12]
        p = wilcoxon(nz).pvalue if len(nz) >= 6 else float('nan')
        print(f'   VulnUp vs {m:28s} mean {st.mean(d):+6.1%}  better {sum(x > 1e-12 for x in d)}/{len(d)}'
              f'  worse {sum(x < -1e-12 for x in d)}  p={p:.3g}')
