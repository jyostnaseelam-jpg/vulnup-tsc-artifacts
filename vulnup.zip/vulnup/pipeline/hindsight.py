"""Hindsight risk signals for outcome validation of replay plans (never used for planning).

HMAX[cve] : the highest EPSS the CVE reached in any monthly file Jan 2024 - Jul 2026.
KEV       : CVEs in CISA's Known Exploited Vulnerabilities catalog (data/kev.csv, Oct 2026).
Cached in data/hindsight.json.gz.
"""
import csv, glob, gzip, json, os
CACHE = 'data/hindsight.json.gz'
if os.path.exists(CACHE):
    with gzip.open(CACHE, 'rt') as f:
        _d = json.load(f)
else:
    hmax = {}
    for p in sorted(glob.glob('data/epss_monthly/epss_scores-*.csv.gz')):
        if not ('2024-01-01' <= os.path.basename(p)[12:22] <= '2026-07-01'):
            continue
        with gzip.open(p, 'rt') as f:
            for line in f:
                if line.startswith('#') or line.startswith('cve,'):
                    continue
                c = line.strip().split(',')
                try:
                    v = float(c[1])
                except (IndexError, ValueError):
                    continue
                if v > hmax.get(c[0], 0.0):
                    hmax[c[0]] = v
    kev = sorted({r['cveID'] for r in csv.DictReader(open('data/kev.csv'))}) if os.path.exists('data/kev.csv') else []
    _d = {'hmax': hmax, 'kev': kev}
    with gzip.open(CACHE, 'wt') as f:
        json.dump(_d, f)
HMAX, KEV = _d['hmax'], set(_d['kev'])
