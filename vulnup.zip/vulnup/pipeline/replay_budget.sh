#!/bin/sh
# Replay robustness at a doubled budget (0.5 per service per month). Log: data/replay_budget.log
for S in 1 2 3 4; do
  f=results/replay/clustered_L3_n25_s${S}_b0.5.csv; [ -f $f ] && continue
  echo "== START clustered seed=$S beta=0.5"
  python3 pipeline/replay.py 25 $S 0.5 30 clustered 2>&1 | grep -E "cumulative|Traceback|Error"
done
echo BUDGET_DONE
