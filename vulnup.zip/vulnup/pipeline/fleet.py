"""Fleet-level, multi-sprint vulnerability-aware upgrade planning (VUP-F).

A fleet is a set of services (projects). Each service has decision dependencies, each with
options (index 0 = refreshed current version). Planning runs over T sprints with a
per-sprint engineering budget B.

Costs
  * local cost of upgrading one dependency in one service:  c_minor + c_major_local * d_major
  * shared learning cost: the first time the fleet crosses a major boundary k -> k+1 of
    package P, it pays L once (migration guide, codemods, review); every later service that
    crosses the same boundary pays only its local cost.
  Learning is paid in the sprint the boundary is first crossed.

Objective: minimize exposure = sum over sprints t = 1..T of risk at the end of sprint t,
where a service's risk is sum_u w_u over advisories still present in its resolved tree.

Plan representation: {(p, j): (k, t)} meaning dependency j of service p moves to option k
in sprint t (absent = stays on option 0). One upgrade per dependency over the horizon.
"""
import math
from collections import defaultdict
import vup
from vulndb import parse

FCFG = {'c_minor': 1, 'c_major_local': 1, 'L': 3}

class Fleet:
    def __init__(self, insts, cfg=vup.DEFAULT, fcfg=FCFG):
        self.f = fcfg
        self.svc = []        # per service: list of deps; dep = list of options
        self.w = []          # per service: advisory -> weight
        for inst in insts:
            deps, w = vup.prepare(inst, cfg)
            sv = []
            for d, (_, opts) in zip(inst['decision_deps'], deps):
                ref_major = parse(d['ref_version']).major
                pkg = d['package']
                ol = []
                for k, (_, A, o) in enumerate(opts):
                    dm = o['d_major']
                    bounds = tuple((pkg, ref_major + b) for b in range(dm)) if dm > 0 else ()
                    local = 0 if k == 0 else fcfg['c_minor'] + fcfg['c_major_local'] * dm
                    ol.append({'A': A, 'local': local, 'bounds': bounds, 'd_major': dm})
                sv.append(ol)
            self.svc.append(sv)
            self.w.append(w)
        self.deps = [(p, j) for p in range(len(self.svc)) for j in range(len(self.svc[p]))]

    # ---------------------------------------------------------------- evaluation
    def risk_service(self, p, state):
        present = set()
        for j, opts in enumerate(self.svc[p]):
            present |= opts[state.get((p, j), 0)]['A']
        return sum(self.w[p][u] for u in present)

    def risk_state(self, state):
        """state: {(p,j): k}. Total risk across services."""
        tot = 0.0
        for p, sv in enumerate(self.svc):
            present = set()
            for j, opts in enumerate(sv):
                present |= opts[state.get((p, j), 0)]['A']
            tot += sum(self.w[p][u] for u in present)
        return tot

    def evaluate(self, plan, T, B):
        """Return (exposure, per-sprint spend list, feasible) for a plan {(p,j): (k,t)}."""
        learned, spend, state, exposure = set(), [0] * (T + 1), {}, 0.0
        for t in range(1, T + 1):
            for (p, j), (k, tt) in sorted(plan.items(), key=lambda kv: kv[1][1]):
                if tt != t:
                    continue
                o = self.svc[p][j][k]
                spend[t] += o['local']
                for b in o['bounds']:
                    if b not in learned:
                        learned.add(b); spend[t] += self.f['L']
                state[(p, j)] = k
            exposure += self.risk_state(state)
        feasible = all(s <= B for s in spend[1:])
        return exposure, spend[1:], feasible

    def marginal_cost(self, p, j, k, learned):
        o = self.svc[p][j][k]
        return o['local'] + self.f['L'] * sum(1 for b in o['bounds'] if b not in learned)

    # ---------------------------------------------------------------- exact (CP-SAT)
    def solve(self, T, B, time_limit=60.0, workers=8, terminal=0.0):
        """terminal: extra weight on risk left at the end of the horizon (rolling-horizon end effect);
        the last sprint's risk counts (1 + terminal) times."""
        from ortools.sat.python import cp_model
        SCALE = 10**6
        m = cp_model.CpModel()
        u = {}                                       # upgrade (p,j) to k in sprint t
        for (p, j) in self.deps:
            for k in range(1, len(self.svc[p][j])):
                for t in range(1, T + 1):
                    u[p, j, k, t] = m.NewBoolVar('')
            m.AddAtMostOne(u[p, j, k, t] for k in range(1, len(self.svc[p][j])) for t in range(1, T + 1))
        bounds = sorted({b for (p, j) in self.deps for o in self.svc[p][j] for b in o['bounds']})
        e = {(b, t): m.NewBoolVar('') for b in bounds for t in range(1, T + 1)}   # learn b in sprint t
        for b in bounds:
            m.AddAtMostOne(e[b, t] for t in range(1, T + 1))
        users = defaultdict(list)
        for (p, j, k, t), var in u.items():
            for b in self.svc[p][j][k]['bounds']:
                m.Add(sum(e[b, tt] for tt in range(1, t + 1)) >= var)
                users[b, t].append(var)
        for (b, t), var in e.items():            # learn a boundary only in a sprint that uses it
            m.Add(var <= sum(users.get((b, t), [])))
        for t in range(1, T + 1):
            m.Add(sum(self.svc[p][j][k]['local'] * var for (p, j, k, tt), var in u.items() if tt == t)
                  + sum(self.f['L'] * e[b, t] for b in bounds) <= B)
        obj = []
        for p, sv in enumerate(self.svc):
            advs = sorted({a for opts in sv for o in opts for a in o['A']})
            for a in advs:
                wa = int(round(self.w[p][a] * SCALE))
                if wa == 0:
                    continue
                for t in range(1, T + 1):
                    z = m.NewBoolVar('')
                    for j, opts in enumerate(sv):
                        for k, o in enumerate(opts):
                            if a not in o['A']:
                                continue
                            if k == 0:   # still on ref at t  <=>  no upgrade by t
                                m.Add(z + sum(u[p, j, kk, tt] for kk in range(1, len(opts))
                                              for tt in range(1, t + 1)) >= 1)
                            else:
                                m.Add(z >= sum(u[p, j, k, tt] for tt in range(1, t + 1)))
                    obj.append((wa * (1 + terminal) if t == T else wa) * z)
        m.Minimize(sum(obj))
        s = cp_model.CpSolver()
        s.parameters.max_time_in_seconds = time_limit
        s.parameters.num_workers = workers
        st = s.Solve(m)
        if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            return {}, {'status': 'none'}
        plan = {(p, j): (k, t) for (p, j, k, t), var in u.items() if s.Value(var)}
        bound = s.BestObjectiveBound() / SCALE
        return plan, {'status': 'optimal' if st == cp_model.OPTIMAL else 'feasible',
                      'bound': bound, 'seconds': s.WallTime()}

    # ---------------------------------------------------------------- baselines
    def _greedy_sprints(self, T, B, pick):
        """Generic sprint loop: `pick(state, learned, remaining)` returns a list of (p,j,k) actions or None."""
        plan, state, learned = {}, {}, set()
        for t in range(1, T + 1):
            rem = B
            while True:
                acts = pick(state, learned, rem)
                if not acts:
                    break
                for (p, j, k) in acts:
                    c = self.marginal_cost(p, j, k, learned)
                    rem -= c
                    learned.update(self.svc[p][j][k]['bounds'])
                    state[(p, j)] = k; plan[(p, j)] = (k, t)
        return plan

    def _cost_of_actions(self, acts, learned):
        lr, c = set(learned), 0
        for (p, j, k) in acts:
            o = self.svc[p][j][k]
            c += o['local'] + self.f['L'] * sum(1 for b in o['bounds'] if b not in lr)
            lr.update(o['bounds'])
        return c

    def _advisory_fix(self, p, a, state):
        """Cheapest-local actions in service p that remove advisory a (None if impossible)."""
        acts = []
        for j, opts in enumerate(self.svc[p]):
            cur = state.get((p, j), 0)
            if a in opts[cur]['A']:
                if (p, j) in state:          # already upgraded once this horizon
                    return None
                cands = [(o['local'] + 10 * o['d_major'], k) for k, o in enumerate(opts) if k > 0 and a not in o['A']]
                if not cands:
                    return None
                acts.append((p, j, min(cands)[1]))
        return acts or None

    def advisory_order_greedy(self, T, B, key):
        """Fix (service, advisory) pairs in a fixed priority order (EPSS-first, severity-first)."""
        pairs = sorted(((p, a) for p in range(len(self.svc)) for a in self.w[p]), key=key)
        done = set()
        def pick(state, learned, rem):
            for p, a in pairs:
                if (p, a) in done:
                    continue
                present = any(a in opts[state.get((p, j), 0)]['A'] for j, opts in enumerate(self.svc[p]))
                if not present:
                    done.add((p, a)); continue
                acts = self._advisory_fix(p, a, state)
                if acts is None:
                    done.add((p, a)); continue
                if self._cost_of_actions(acts, learned) <= rem:
                    done.add((p, a)); return acts
            return None
        return self._greedy_sprints(T, B, pick)

    def ratio_greedy(self, T, B, waves=False):
        """Fleet-aware: repeatedly take the action with the best risk reduction per marginal cost.
        With waves=True an action may also be 'upgrade package P to option version v in every
        service that uses it' (a platform-team migration wave), so shared learning is amortized."""
        def pick(state, learned, rem):
            best, best_r = None, 0.0
            cur = {p: self.risk_service(p, state) for p in range(len(self.svc))}
            cands = []
            for (p, j) in self.deps:
                if (p, j) in state:
                    continue
                for k in range(1, len(self.svc[p][j])):
                    cands.append([(p, j, k)])
            if waves:
                by = defaultdict(list)
                for (p, j) in self.deps:
                    if (p, j) in state:
                        continue
                    for k in range(1, len(self.svc[p][j])):
                        o = self.svc[p][j][k]
                        if o['bounds']:
                            by[o['bounds'][-1]].append((p, j, k))
                for acts in by.values():
                    seen, uniq = set(), []
                    for a in acts:
                        if (a[0], a[1]) not in seen:
                            seen.add((a[0], a[1])); uniq.append(a)
                    if len(uniq) > 1:
                        cands.append(uniq)
            for acts in cands:
                c = self._cost_of_actions(acts, learned)
                if c > rem or c <= 0:
                    continue
                st2 = dict(state); st2.update({(p, j): k for p, j, k in acts})
                gain = sum(cur[p] - self.risk_service(p, st2) for p in {a[0] for a in acts})
                if gain / c > best_r + 1e-15:
                    best, best_r = acts, gain / c
            return best
        return self._greedy_sprints(T, B, pick)

    def myopic_sprint_optimal(self, T, B, time_limit=20.0):
        """Each sprint, solve the one-sprint fleet problem exactly from the current state (no look-ahead)."""
        plan, state, learned = {}, {}, set()
        for t in range(1, T + 1):
            sub = _Residual(self, state, learned)
            p1, _ = sub.solve(1, B, time_limit=time_limit)
            for (p, j), (k, _) in p1.items():
                plan[(p, j)] = (k, t); state[(p, j)] = k
                learned.update(self.svc[p][j][k]['bounds'])
        return plan

class _Residual(Fleet):
    """A fleet view where upgraded dependencies are frozen and learned boundaries are free."""
    def __init__(self, base, state, learned):
        self.f = base.f; self.w = base.w; self.svc = []
        for p, sv in enumerate(base.svc):
            nsv = []
            for j, opts in enumerate(sv):
                if (p, j) in state:
                    o = opts[state[(p, j)]]
                    nsv.append([dict(o, local=0, bounds=())])
                else:
                    nsv.append([dict(o, bounds=tuple(b for b in o['bounds'] if b not in learned)) for o in opts])
            self.svc.append(nsv)
        self.deps = [(p, j) for p in range(len(self.svc)) for j in range(len(self.svc[p]))]
