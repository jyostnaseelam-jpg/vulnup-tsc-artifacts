"""Replay metric that is robust to EPSS model changes: the mean over months of the share of refresh-only exposure
removed that month (each month weighs equally, so the ~3x rescaling of EPSS v4 in April 2025 does not let
post-switch months dominate). Usage: python pipeline/replay_monthly.py <glob> [column]"""
import csv, glob, random, statistics as st, sys
from collections import defaultdict
from scipy.stats import wilcoxon
MAIN = sys.argv[3] if len(sys.argv) > 3 else 'VulnUp-Fleet (look-ahead 3)'
col = sys.argv[2] if len(sys.argv) > 2 else 'exposure'
def fleet_score(f, extra=None):
    E = defaultdict(dict)
    for fn in [f] + ([extra] if extra else []):
        for r in csv.DictReader(open(fn)):
            E[r['month']][r['method']] = float(r[col])
    sc = defaultdict(list)
    for mth, e in E.items():
        ref = e['Refresh only']
        if ref <= 0:
            continue
        for m, v in e.items():
            sc[m].append((ref - v) / ref)
    return {m: st.mean(v) for m, v in sc.items()} if sc else None
def boot(d, B=10000):
    r = random.Random(1); m = sorted(st.mean(r.choices(d, k=len(d))) for _ in range(B)); return m[250], m[9750]
if __name__ == '__main__':
    files = sorted(glob.glob(sys.argv[1]))
    S = [s for s in (fleet_score(f) for f in files) if s]
    print(len(S), 'fleets with exposure; metric =', col)
    for m in S[0]:
        print(f'  {m:42s} {st.mean(s[m] for s in S):6.1%}')
    for m in S[0]:
        if m in (MAIN, 'Refresh only'):
            continue
        d = [s[MAIN] - s[m] for s in S]; nz = [x for x in d if abs(x) > 1e-12]
        p = wilcoxon(nz, method='exact').pvalue if len(nz) >= 5 else float('nan'); lo, hi = boot(d)
        print(f'  vs {m:39s} {st.mean(d)*100:+5.2f} [{lo*100:+.2f},{hi*100:+.2f}] better {sum(x>1e-12 for x in d)} worse {sum(x<-1e-12 for x in d)} p={p:.3g}')
