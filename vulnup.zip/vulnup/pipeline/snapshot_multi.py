"""Like snapshot_lockfiles.py, but extracts several dates from one clone and then deletes it.

usage: python pipeline/snapshot_multi.py candidates.csv 2024-01-01,2026-07-01 [workdir] [threads]
output: data/lockfiles/<date>/<owner>__<repo>.{lock,pkg}.json and data/lockfiles/<date>/index.csv
Resumable: repos already present in every date's index are skipped.
"""
import csv, os, shutil, subprocess, sys, threading, concurrent.futures as cf

CAND, DATES = sys.argv[1], sys.argv[2].split(',')
WORK = sys.argv[3] if len(sys.argv) > 3 else os.path.join(os.environ.get('TMPDIR', '/tmp'), 'vulnup_clones')
THREADS = int(sys.argv[4]) if len(sys.argv) > 4 else 12
os.makedirs(WORK, exist_ok=True)
OUT = {d: os.path.join('data', 'lockfiles', d) for d in DATES}
for d in OUT.values():
    os.makedirs(d, exist_ok=True)
lock = threading.Lock()

def run(cmd, cwd=None, timeout=900):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)

def done_repos(date):
    p = os.path.join(OUT[date], 'index.csv')
    return {r['repo'] for r in csv.DictReader(open(p))} if os.path.exists(p) else set()

def append(date, row):
    p = os.path.join(OUT[date], 'index.csv')
    with lock:
        new = not os.path.exists(p)
        with open(p, 'a', newline='') as f:
            w = csv.writer(f)
            if new:
                w.writerow(['repo', 'status', 'commit', 'commit_date'])
            w.writerow(row)

def snap(row):
    repo, branch = row['repo'], row['branch']
    slug = repo.replace('/', '__')
    d = os.path.join(WORK, slug)
    try:
        r = run(['git', 'clone', '-q', '--filter=tree:0', '--no-checkout', '--single-branch',
                 '--branch', branch, f'https://github.com/{repo}.git', d])
        if r.returncode:
            for date in DATES:
                append(date, [repo, 'clone-failed', '', ''])
            return
        for date in DATES:
            sha = run(['git', 'rev-list', '-1', f'--before={date}T00:00:00Z', 'HEAD'], cwd=d).stdout.strip()
            if not sha:
                append(date, [repo, 'no-commit-before-date', '', '']); continue
            when = run(['git', 'show', '-s', '--format=%cI', sha], cwd=d).stdout.strip()
            lk = run(['git', 'show', f'{sha}:package-lock.json'], cwd=d)
            if lk.returncode:
                append(date, [repo, 'no-lockfile-at-date', sha, when]); continue
            pkg = run(['git', 'show', f'{sha}:package.json'], cwd=d)
            open(os.path.join(OUT[date], slug + '.lock.json'), 'w').write(lk.stdout)
            open(os.path.join(OUT[date], slug + '.pkg.json'), 'w').write(pkg.stdout if pkg.returncode == 0 else '{}')
            append(date, [repo, 'ok', sha, when])
    except subprocess.TimeoutExpired:
        for date in DATES:
            append(date, [repo, 'timeout', '', ''])
    finally:
        shutil.rmtree(d, ignore_errors=True)

if __name__ == '__main__':
    rows = list(csv.DictReader(open(CAND)))
    skip = set.intersection(*(done_repos(d) for d in DATES))
    todo = [r for r in rows if r['repo'] not in skip]
    print(f'{len(rows)} candidates, {len(skip)} already done, {len(todo)} to snapshot', flush=True)
    with cf.ThreadPoolExecutor(THREADS) as ex:
        for i, _ in enumerate(ex.map(snap, todo), 1):
            if i % 100 == 0:
                print(f'{i}/{len(todo)}', flush=True)
    print('finished', flush=True)
