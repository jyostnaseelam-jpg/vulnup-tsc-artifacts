"""Derived statistics for the feasibility write-up (reads results/<date>/)."""
import csv, json, sys, statistics, collections
DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
rows = list(csv.DictReader(open(f'results/{DATE}/nodes.csv')))
projs = list(csv.DictReader(open(f'results/{DATE}/projects.csv')))
prod = [r for r in rows if r['dev_only'] == 'False']
nu_t = [r for r in rows if r['class'] == 'needs-upgrade' and r['is_direct'] == 'False']
def bucket(k): k = int(k); return '1' if k == 1 else ('2-5' if k <= 5 else '6+')
impl = sorted(int(p['direct_deps_implicated']) for p in projs if int(p['needs_upgrade']))
out = {
    'prod_class_counts': dict(collections.Counter(r['class'] for r in prod)),
    'needs_upgrade_transitive': len(nu_t),
    'needs_upgrade_transitive_carriers': dict(collections.Counter(bucket(r['n_carriers']) for r in nu_t)),
    'direct_vulnerable_nodes': sum(r['is_direct'] == 'True' for r in rows),
    'per_project_vulnerable_median': statistics.median(int(p['vulnerable_nodes']) for p in projs),
    'per_project_vulnerable_max': max(int(p['vulnerable_nodes']) for p in projs),
    'projects_with_prod_vulnerable': sum(int(p['vulnerable_prod_nodes']) > 0 for p in projs),
    'direct_deps_implicated': impl,
    'direct_deps_implicated_median': statistics.median(impl) if impl else 0,
    'direct_deps_implicated_p75': impl[int(0.75 * (len(impl) - 1))] if impl else 0,
}
json.dump(out, open(f'results/{DATE}/derived.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
