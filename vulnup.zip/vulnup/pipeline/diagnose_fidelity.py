"""Why do some needs-upgrade advisories from the lockfile vanish in the resolver's refreshed tree?

For each such advisory, find the vulnerable package in the resolver's closure of the project's direct deps:
  present-fixed : the package is still installed but at a fixed version (a deep refresh of an
                  intermediate parent fixed it; the lockfile-local test was too strict)
  absent        : the package is not installed at all after refresh (a parent dropped it, or an
                  edge the resolver does not model, e.g. peer or bundled dependencies)
"""
import csv, json, os, sys, glob, random
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(__file__))
sys.argv = [sys.argv[0], '2024-01-01', '0']           # reuse build_instances' resolver without rebuilding
exec(open(os.path.join(os.path.dirname(__file__), 'build_instances.py')).read().split('# ---------------------------------------------------------------- sample')[0])

DATE = '2024-01-01'
nodes = defaultdict(list)
for r in csv.DictReader(open(f'results/{DATE}/nodes.csv')):
    nodes[r['repo']].append(r)
outcome = Counter(); examples = defaultdict(list)
for f in sorted(glob.glob(f'instances/{DATE}/*.json')):
    if os.path.basename(f).startswith('_'):
        continue
    inst = json.load(open(f)); repo = inst['repo']
    ref = {a for d in inst['decision_deps'] for a in d['options'][0]['advisories']}
    # closure of every direct dependency at its refreshed version (decision or not)
    slug = repo.replace('/', '__')
    from lockgraph import load
    g = load(f'data/lockfiles/{DATE}/{slug}.lock.json', f'data/lockfiles/{DATE}/{slug}.pkg.json')
    roots = []
    ensure({split_alias(g.nodes[p]['name'], refs[0][1])[0] for p, refs in g.direct.items()})
    for path, refs in g.direct.items():
        r = resolve(g.nodes[path]['name'], refs[0][1])
        if r: roots.append(r)
    ensure({n for n, _ in roots}); expand(roots)
    installed = defaultdict(set)
    for root in roots:
        seen, stack = {root}, [root]
        while stack:
            u = stack.pop(); installed[u[0]].add(u[1])
            for c in children(u):
                if c not in seen:
                    seen.add(c); stack.append(c)
    for r in nodes[repo]:
        if r['class'] == 'refresh':
            continue
        for a in r['advisories'].split():
            if a in ref:
                outcome['kept'] += 1; continue
            vs = installed.get(r['package'], set())
            k = 'present-fixed' if vs else ('absent-dev-only' if r['dev_only'] == 'True' else 'absent-prod')
            outcome[k] += 1
            if len(examples[k]) < 6:
                examples[k].append((repo, r['package'], r['version'], sorted(vs)[:3], r['carriers'][:60]))
print(dict(outcome))
for k, ex in examples.items():
    print(k)
    for e in ex:
        print('   ', e)
