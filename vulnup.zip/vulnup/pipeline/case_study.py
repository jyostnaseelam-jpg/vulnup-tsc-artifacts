"""Case study: compare VulnUp-Fleet and EPSS-first plans on one stack-similar fleet.

usage: python pipeline/case_study.py <seed> <beta> [L] [N]
Prints, per method: exposure reduction, upgrades per sprint, migrations learned (package, boundary)
with the number of services that crossed each, and the advisories removed by each method only.
"""
import glob, json, os, random, sys
from collections import defaultdict, Counter
sys.path.insert(0, os.path.dirname(__file__))
import fleet, vup
from world import World, INFO

SEED, BETA = int(sys.argv[1]), float(sys.argv[2])
L = int(sys.argv[3]) if len(sys.argv) > 3 else 3
N = int(sys.argv[4]) if len(sys.argv) > 4 else 25
T = 4
W = World('2024-01-01')
insts = []
for f in sorted(glob.glob('instances/2024-01-01/*.json')):
    if os.path.basename(f).startswith('_'):
        continue
    inst = json.load(open(f))
    deps, w = vup.prepare(inst)
    if deps and vup.risk_of(deps, w, [0] * len(deps)) > 0:
        insts.append(inst)
for inst in insts:                                   # same order as run_fleet.py: filter first, then EPSS
    for u, a in inst['advisories'].items():
        a['epss'] = W.epss_of(u)
rng = random.Random(SEED * 1000 + N)
pk = [{d['package'] for d in i['decision_deps']} for i in insts]
order = list(range(len(insts))); rng.shuffle(order)
chosen = [order[0]]; pool = set(order[1:]); fp = set(pk[order[0]])
while len(chosen) < N:
    b = max(pool, key=lambda q: (len(pk[q] & fp), rng.random()))
    chosen.append(b); pool.discard(b); fp |= pk[b]
picked = [insts[q] for q in chosen]
F = fleet.Fleet(picked, fcfg=dict(fleet.FCFG, L=L))
B = max(1, round(BETA * N))
r0 = F.risk_state({})

plans = {'VulnUp-Fleet': F.solve(T, B, time_limit=120)[0],
         'EPSS-first': F.advisory_order_greedy(T, B, key=lambda pa: (-(picked[pa[0]]['advisories'][pa[1]]['epss'] or 0), pa)),
         'Fleet-aware greedy + waves': F.ratio_greedy(T, B, waves=True)}
removed = {}
for name, plan in plans.items():
    E, spend, ok = F.evaluate(plan, T, B)
    learned = Counter()
    crossings = defaultdict(set)
    for (p, j), (k, t) in plan.items():
        for b in F.svc[p][j][k]['bounds']:
            crossings[b].add(p)
    state = {(p, j): k for (p, j), (k, t) in plan.items()}
    present_after = {(p, u) for p in range(len(F.svc)) for j, o in enumerate(F.svc[p]) for u in o[state.get((p, j), 0)]['A']}
    present_before = {(p, u) for p in range(len(F.svc)) for j, o in enumerate(F.svc[p]) for u in o[0]['A']}
    removed[name] = present_before - present_after
    print(f'\n== {name}: reduction {(T * r0 - E) / (T * r0):.1%}, spend per sprint {spend}, feasible {ok}, '
          f'upgrades {len(plan)}, majors {sum(F.svc[p][j][k]["d_major"] > 0 for (p, j), (k, t) in plan.items())}')
    for b, ps in sorted(crossings.items(), key=lambda kv: -len(kv[1])):
        print(f'   learned {b[0]} {b[1]}->{b[1] + 1}: crossed by {len(ps)} services')
    print(f'   (service, advisory) pairs removed: {len(removed[name])} of {len(present_before)}; '
          f'weight removed {sum(F.w[p][u] for p, u in removed[name]):.4f} of {sum(F.w[p][u] for p, u in present_before):.4f}')
only = removed['VulnUp-Fleet'] - removed['EPSS-first']
print('\nremoved only by VulnUp:', len(only), 'weight', round(sum(F.w[p][u] for p, u in only), 4))
top = Counter(u for _, u in only)
for u, c in top.most_common(8):
    a = INFO.get(u, {})
    print(f'   {u} sev={a.get("severity")} epss={W.epss_of(u)} services={c} pkg-carriers?')
only2 = removed['EPSS-first'] - removed['VulnUp-Fleet']
print('removed only by EPSS-first:', len(only2), 'weight', round(sum(F.w[p][u] for p, u in only2), 4))

print('\nupgrades by package (package: services, majors) per method')
for name, plan in plans.items():
    c = Counter(); maj = Counter(); first = {}
    for (p, j), (k, t) in plan.items():
        d = picked[p]['decision_deps'][j]; o = d['options'][k]
        c[d['package']] += 1; maj[d['package']] += o['d_major'] > 0
        first[d['package']] = min(first.get(d['package'], 9), t)
    print(' ', name, '; '.join(f"{pk_}:{n}{'M' * 0}{'(maj %d)' % maj[pk_] if maj[pk_] else ''}@s{first[pk_]}" for pk_, n in c.most_common()))
for u in ('GHSA-29mw-wpgm-hmr9', 'GHSA-cph5-m8f7-6c5x', 'GHSA-xvch-5gv4-984h', 'GHSA-35jh-r3h4-6jhm'):
    pkgs = [n for n, lst in __import__('vulndb').AdvisoryIndex().idx.items() if any(a['id'] == u for a in lst)]
    print(u, pkgs, INFO[u].get('cves'))
