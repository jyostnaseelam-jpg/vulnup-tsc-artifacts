"""Figure: monthly exposure relative to refresh-only, averaged over replay fleets (one panel per fleet type)."""
import csv, glob, os
from collections import defaultdict
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = os.path.join('..', 'paper', 'figures'); os.makedirs(OUT, exist_ok=True)
SHOW = [('VulnUp-Fleet (look-ahead 3)', 'VulnUp-Fleet', '#1f5fbf', '-'),
        ('Fleet-aware greedy', 'Fleet-aware greedy', '#555555', '--'),
        ('EPSS-first greedy', 'EPSS-first', '#888888', '-.'),
        ('Severity-first greedy', 'Severity-first', '#bbbbbb', ':')]
plt.rcParams.update({'font.size': 7, 'font.family': 'serif', 'axes.linewidth': 0.5})
fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.1), sharey=True)
for ax, mode, title in zip(axes, ('clustered', 'random'), ('Stack-similar fleets (8)', 'Random fleets (6)')):
    ratio = defaultdict(lambda: defaultdict(list))
    for f in glob.glob(f'results/replay/{mode}_*.csv'):
        ex = defaultdict(dict)
        for r in csv.DictReader(open(f)):
            ex[r['month']][r['method']] = float(r['exposure'])
        for mth, d in ex.items():
            for m, _, _, _ in SHOW:
                ratio[m][mth].append(d[m] / d['Refresh only'] if d['Refresh only'] > 0 else 1.0)
    months = sorted(next(iter(ratio.values())))
    for m, label, col, ls in SHOW:
        ax.plot(range(len(months)), [sum(ratio[m][t]) / len(ratio[m][t]) for t in months],
                color=col, ls=ls, lw=1.2 if m.startswith('VulnUp') else 0.9, label=label)
    ax.set_title(title, fontsize=7.5)
    ticks = [i for i, t in enumerate(months) if t.endswith('-01-01') or t.endswith('-07-01')]
    ax.set_xticks(ticks); ax.set_xticklabels([months[i][:7] for i in ticks])
    ax.set_ylim(0, 1.05); ax.grid(axis='y', lw=0.3, color='#dddddd')
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
axes[0].set_ylabel('Exposure / refresh-only')
axes[1].legend(frameon=False, loc='lower left', fontsize=6.5)
fig.tight_layout()
fig.savefig(os.path.join(OUT, 'replay_monthly.pdf'))
print('saved')
