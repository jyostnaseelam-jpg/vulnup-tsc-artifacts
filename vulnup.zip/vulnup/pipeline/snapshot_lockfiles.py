"""Extract each repo's root package-lock.json + package.json as of a snapshot date.

Uses a treeless git clone (commit history only; trees and blobs fetched on
demand), so no GitHub API token is needed.

usage: python pipeline/snapshot_lockfiles.py 2024-01-01 [workdir]
output: data/lockfiles/<date>/<owner>__<repo>.{lock.json,pkg.json} + index.csv
"""
import csv, os, subprocess, sys, shutil, concurrent.futures as cf

DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
WORK = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.environ.get('TMPDIR', '/tmp'), 'vulnup_clones')
OUT = os.path.join('data', 'lockfiles', DATE)
os.makedirs(OUT, exist_ok=True); os.makedirs(WORK, exist_ok=True)

def run(cmd, cwd=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=900)

def snap(row):
    repo, branch = row['repo'], row['branch']
    slug = repo.replace('/', '__')
    d = os.path.join(WORK, slug)
    if not os.path.isdir(d):
        r = run(['git', 'clone', '-q', '--filter=tree:0', '--no-checkout', '--single-branch',
                 '--branch', branch, f'https://github.com/{repo}.git', d])
        if r.returncode:
            return repo, 'clone-failed', '', ''
    sha = run(['git', 'rev-list', '-1', f'--before={DATE}T00:00:00Z', 'HEAD'], cwd=d).stdout.strip()
    if not sha:
        return repo, 'no-commit-before-date', '', ''
    when = run(['git', 'show', '-s', '--format=%cI', sha], cwd=d).stdout.strip()
    lock = run(['git', 'show', f'{sha}:package-lock.json'], cwd=d)
    if lock.returncode:
        return repo, 'no-lockfile-at-date', sha, when
    pkg = run(['git', 'show', f'{sha}:package.json'], cwd=d)
    open(os.path.join(OUT, slug + '.lock.json'), 'w').write(lock.stdout)
    open(os.path.join(OUT, slug + '.pkg.json'), 'w').write(pkg.stdout if pkg.returncode == 0 else '{}')
    return repo, 'ok', sha, when

if __name__ == '__main__':
    rows = list(csv.DictReader(open('data/candidates.csv')))
    with cf.ThreadPoolExecutor(8) as ex:
        res = list(ex.map(snap, rows))
    with open(os.path.join(OUT, 'index.csv'), 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['repo', 'status', 'commit', 'commit_date']); w.writerows(res)
    from collections import Counter
    print(Counter(r[1] for r in res))
