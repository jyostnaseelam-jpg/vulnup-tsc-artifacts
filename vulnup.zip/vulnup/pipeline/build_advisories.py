"""Build a compact npm advisory index from GitHub's reviewed advisory database (OSV format)
and join CISA KEV.

inputs : data/adb/advisories/github-reviewed/**.json   (git clone of github/advisory-database)
         data/kev.json                                  (cisagov/kev-data)
         data/epss.csv (optional)                       (FIRST EPSS daily CSV, columns cve,epss,percentile)
output : data/npm_advisories.json  -> {package_name: [advisory, ...]}
"""
import glob, json, os, csv, gzip
from collections import defaultdict

SEV = {'LOW': 1, 'MODERATE': 2, 'MEDIUM': 2, 'HIGH': 3, 'CRITICAL': 4}

def load_kev(path='data/kev.json'):
    if not os.path.exists(path):
        return {}
    d = json.load(open(path))
    return {v['cveID']: v.get('dateAdded', '') for v in d.get('vulnerabilities', [])}

def load_epss(path='data/epss.csv'):
    if not os.path.exists(path):
        if os.path.exists(path + '.gz'):
            path += '.gz'
        else:
            return {}
    op = gzip.open if path.endswith('.gz') else open
    out = {}
    with op(path, 'rt') as f:
        for line in f:
            if line.startswith('#') or line.startswith('cve,'):
                continue
            p = line.strip().split(',')
            if len(p) >= 2:
                out[p[0]] = float(p[1])
    return out

def main():
    kev, epss = load_kev(), load_epss()
    idx = defaultdict(list)
    n = 0
    for fp in glob.glob('data/adb/advisories/github-reviewed/**/*.json', recursive=True):
        a = json.load(open(fp))
        cves = [x for x in a.get('aliases', []) if x.startswith('CVE-')]
        sev = (a.get('database_specific') or {}).get('severity', '').upper()
        cwes = (a.get('database_specific') or {}).get('cwe_ids', [])
        for aff in a.get('affected', []):
            pkg = aff.get('package', {})
            if pkg.get('ecosystem') != 'npm':
                continue
            ranges = []
            for r in aff.get('ranges', []):
                if r.get('type') in ('SEMVER', 'ECOSYSTEM'):   # GitHub uses ECOSYSTEM for npm
                    ranges.append(r.get('events', []))
            rec = {
                'id': a['id'], 'cves': cves, 'published': a.get('published', ''),
                'withdrawn': a.get('withdrawn', ''), 'severity': sev, 'sev_level': SEV.get(sev, 0),
                'cwes': cwes, 'ranges': ranges, 'versions': aff.get('versions', []),
                'kev': any(c in kev for c in cves),
                'kev_added': min([kev[c] for c in cves if c in kev], default=''),
                'epss': max([epss[c] for c in cves if c in epss], default=None),
            }
            idx[pkg['name']].append(rec); n += 1
    json.dump(idx, open('data/npm_advisories.json', 'w'))
    print(f'{n} npm advisory entries over {len(idx)} packages; KEV list {len(kev)} CVEs; EPSS rows {len(epss)}')
    print('KEV-listed npm advisories:', sum(r['kev'] for v in idx.values() for r in v))

if __name__ == '__main__':
    main()
