"""Dataset characterization for the paper (instances of 2024-01-01, EPSS of 2024-01-01).

Prints: instance size statistics, coupling structure (components, uncoupled share), and
EPSS-by-severity statistics with Spearman correlation. Writes results/2024-01-01/characterize.json.
"""
import glob, json, os, sys, statistics as st
from collections import Counter
sys.path.insert(0, os.path.dirname(__file__))
import vup
from world import World
from scipy.stats import spearmanr

W = World('2024-01-01')
files = sorted(f for f in glob.glob('instances/2024-01-01/*.json') if not os.path.basename(f).startswith('_'))
dec, opts, comps_largest, n_comps, coupled_adv, all_adv = [], [], [], [], 0, 0
adv_seen = {}
for f in files:
    inst = json.load(open(f))
    for u, a in inst['advisories'].items():
        a['epss'] = W.epss_of(u)
    deps, w = vup.prepare(inst)
    if not deps or vup.risk_of(deps, w, [0] * len(deps)) <= 0:
        continue
    dec.append(len(deps)); opts += [len(o) for _, o in deps]
    cs = vup.components(deps)
    comps_largest.append(max(len(c) for c in cs)); n_comps.append(len(cs))
    carriers = {}
    for j, (_, o) in enumerate(deps):
        for _, A, _ in o:
            for u in A:
                carriers.setdefault(u, set()).add(j)
    all_adv += len(carriers); coupled_adv += sum(len(s) > 1 for s in carriers.values())
    for u, a in inst['advisories'].items():
        adv_seen[u] = (a['severity'], a['epss'])

def bucket(s):
    return '1' if s == 1 else '2' if s == 2 else '3-5' if s <= 5 else '6-10' if s <= 10 else '11+'
hist = Counter(bucket(s) for s in comps_largest)
sev_names = {1: 'Low', 2: 'Moderate', 3: 'High', 4: 'Critical'}
by_sev = {}
pairs = [(s, e) for s, e in adv_seen.values() if e is not None and s in sev_names]
for s in sorted(sev_names):
    v = sorted(e for ss, e in pairs if ss == s)
    if v:
        q = lambda p: v[min(len(v) - 1, int(p * (len(v) - 1)))]
        by_sev[sev_names[s]] = {'n': len(v), 'q25': q(.25), 'median': q(.5), 'q75': q(.75), 'q90': q(.9),
                                'share_below_1pct': sum(x < 0.01 for x in v) / len(v),
                                'share_above_10pct': sum(x >= 0.10 for x in v) / len(v)}
rho = spearmanr([s for s, _ in pairs], [e for _, e in pairs])
out = {
    'projects': len(dec), 'decision_deps_median': st.median(dec), 'decision_deps_p90': sorted(dec)[int(.9 * (len(dec) - 1))],
    'decision_deps_max': max(dec), 'options_median': st.median(opts), 'options_max': max(opts),
    'components_median': st.median(n_comps), 'largest_component_hist': dict(hist),
    'projects_fully_uncoupled': sum(s == 1 for s in comps_largest),
    'largest_component_max': max(comps_largest),
    'advisory_carrier_pairs': all_adv, 'coupled_share': coupled_adv / all_adv,
    'unique_advisories': len(adv_seen), 'with_epss': len(pairs),
    'epss_by_severity': by_sev, 'spearman_severity_epss': {'rho': rho.statistic, 'p': rho.pvalue},
}
json.dump(out, open('results/2024-01-01/characterize.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
