"""Summarize the fleet grid: mean exposure reduction per method, and VulnUp's paired gain over each baseline."""
import csv, glob, statistics as st, sys
from collections import defaultdict
from scipy.stats import wilcoxon

rows = []
for f in glob.glob(sys.argv[1] if len(sys.argv) > 1 else 'results/2024-01-01/fleet/*_T4.csv'):
    rows += list(csv.DictReader(open(f)))
for r in rows:
    r['reduction'] = float(r['reduction'])
methods = list(dict.fromkeys(r['method'] for r in rows))
key = lambda r: (r['mode'], r['L'], r['fleet_size'], r['seed'], r['beta'])
by = defaultdict(dict)
for r in rows:
    by[key(r)][r['method']] = r

print(f"{len(by)} fleet x budget cases; solver status:",
      dict(st_ for st_ in __import__('collections').Counter(r['status'] for r in rows if r['method'] == 'VulnUp-Fleet').items()))
for mode in ('clustered', 'random'):
    for L in ('3', '8'):
        cases = [k for k in by if k[0] == mode and k[1] == L]
        if not cases:
            continue
        print(f'\n== {mode} fleets, learning cost L={L}  ({len(cases)} cases)')
        for m in methods:
            v = [by[k][m]['reduction'] for k in cases]
            print(f'   {m:24s} mean exposure reduction {st.mean(v):6.1%}')
        for m in methods:
            if m in ('VulnUp-Fleet', 'Refresh only'):
                continue
            d = [by[k]['VulnUp-Fleet']['reduction'] - by[k][m]['reduction'] for k in cases]
            nz = [x for x in d if abs(x) > 1e-9]
            p = wilcoxon(nz).pvalue if len(nz) >= 6 else float('nan')
            print(f'   gain over {m:24s} mean {st.mean(d):+6.1%}  max {max(d):+6.1%}  better in {sum(x > 1e-9 for x in d)}/{len(d)}'
                  f'  worse in {sum(x < -1e-9 for x in d)}  p={p:.1e}')
# by fleet size (clustered, all L)
print('\n== gain over best baseline by fleet size (clustered)')
for n in ('10', '25', '50'):
    cases = [k for k in by if k[0] == 'clustered' and k[2] == n]
    if cases:
        d = [by[k]['VulnUp-Fleet']['reduction'] - max(by[k][m]['reduction'] for m in methods if m not in ('VulnUp-Fleet', 'Myopic sprint-optimal'))
             for k in cases]
        print(f'   n={n}: mean {st.mean(d):+6.1%}, median {st.median(d):+6.1%}, max {max(d):+6.1%} ({len(cases)} cases)')
