"""Advisory matching (OSV SEMVER events) and npm registry release times, with an on-disk cache."""
import json, os, urllib.parse
import requests, semver, nodesemver

def parse(v):
    try:
        return semver.Version.parse(v.lstrip('v=').strip())
    except Exception:
        return None

def in_range(ver, events):
    """OSV SEMVER semantics: introduced opens an interval; fixed (exclusive) or last_affected (inclusive) closes it."""
    v = parse(ver)
    if v is None:
        return False
    lo = None
    for ev in events:
        if 'introduced' in ev:
            lo = parse('0.0.0') if ev['introduced'] == '0' else parse(ev['introduced'])
        elif 'fixed' in ev and lo is not None:
            hi = parse(ev['fixed'])
            if hi is not None and lo <= v < hi:
                return True
            lo = None
        elif 'last_affected' in ev and lo is not None:
            hi = parse(ev['last_affected'])
            if hi is not None and lo <= v <= hi:
                return True
            lo = None
    return lo is not None and v >= lo   # open-ended: no fix yet

class AdvisoryIndex:
    def __init__(self, path='data/npm_advisories.json'):
        self.idx = json.load(open(path))

    def known_at(self, adv, date):
        if not adv['published'] or adv['published'][:10] >= date:
            return False
        return not (adv['withdrawn'] and adv['withdrawn'][:10] < date)

    def affecting(self, name, version, date):
        out = []
        for a in self.idx.get(name, []):
            if not self.known_at(a, date):
                continue
            if version in a['versions'] or any(in_range(version, ev) for ev in a['ranges']):
                out.append(a)
        return out

class Registry:
    """version -> publish time for a package, from registry.npmjs.org (cached)."""
    def __init__(self, cache='data/registry'):
        self.cache = cache; os.makedirs(cache, exist_ok=True)
        self.s = requests.Session()

    def times(self, name):
        fp = os.path.join(self.cache, urllib.parse.quote(name, safe='') + '.json')
        if os.path.exists(fp):
            return json.load(open(fp))
        r = self.s.get('https://registry.npmjs.org/' + urllib.parse.quote(name, safe='@'), timeout=120)
        t = {}
        if r.status_code == 200:
            doc = r.json()
            t = {k: v for k, v in (doc.get('time') or {}).items() if k not in ('created', 'modified')}
        json.dump(t, open(fp, 'w'))
        return t

def satisfies(version, spec):
    try:
        return nodesemver.satisfies(version, spec, loose=True)
    except Exception:
        return False

def is_semver_spec(spec):
    s = (spec or '').strip()
    bad = ('file:', 'link:', 'git', 'http:', 'https:', 'npm:', 'workspace:', 'github:', 'portal:')
    if any(s.startswith(b) for b in bad) or '/' in s and not s.startswith('<') and not s.startswith('>'):
        return False
    try:
        nodesemver.make_range(s or '*', loose=True)
        return True
    except Exception:
        return False
