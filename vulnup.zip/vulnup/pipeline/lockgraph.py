"""Parse an npm package-lock.json (v1, v2 or v3) into a resolved dependency graph.

Node id = install path ('' for the root, 'node_modules/a/node_modules/b', or a
workspace folder such as 'packages/x'). Edges follow Node's module-resolution
rule: look in <path>/node_modules, then each ancestor, then the root.
"""
import json

class LockGraph:
    def __init__(self, lock, pkg_json=None):
        self.nodes = {}   # path -> dict(name, version, dev, deps={name: spec})
        self.edges = {}   # path -> {dep_name: (target_path, spec)}
        self.roots = []
        v = lock.get('lockfileVersion', 1)
        if v >= 2 and 'packages' in lock:
            self._from_v2(lock)
        else:
            self._from_v1(lock, pkg_json or {})
        self._resolve()

    @staticmethod
    def _name_from_path(path):
        i = path.rfind('node_modules/')
        return path[i + len('node_modules/'):] if i >= 0 else path

    def _from_v2(self, lock):
        pk = lock['packages']
        self.links = {}
        for path, e in pk.items():
            if e.get('link'):
                self.links[path] = e.get('resolved', '')
                continue
            deps = {}
            for k in ('dependencies', 'optionalDependencies', 'peerDependencies'):
                deps.update(e.get(k) or {})
            if 'node_modules' not in path:          # root or workspace package
                deps.update(e.get('devDependencies') or {})
                self.roots.append(path)
            self.nodes[path] = {
                'name': e.get('name') or (self._name_from_path(path) if path else lock.get('name', '<root>')),
                'version': e.get('version', ''),
                'dev': bool(e.get('dev')) or bool(e.get('devOptional')),
                'deps': deps,
                'root': 'node_modules' not in path,
            }

    def _from_v1(self, lock, pkg_json):
        self.links = {}
        root_deps = {}
        for k in ('dependencies', 'devDependencies', 'optionalDependencies'):
            root_deps.update(pkg_json.get(k) or {})
        self.nodes[''] = {'name': lock.get('name', '<root>'), 'version': lock.get('version', ''),
                          'dev': False, 'deps': root_deps, 'root': True}
        self.roots.append('')
        def walk(parent, deps):
            for name, e in (deps or {}).items():
                path = (parent + '/node_modules/' + name) if parent else 'node_modules/' + name
                self.nodes[path] = {'name': name, 'version': e.get('version', ''),
                                    'dev': bool(e.get('dev')), 'deps': dict(e.get('requires') or {}),
                                    'root': False}
                walk(path, e.get('dependencies'))
        walk('', lock.get('dependencies'))

    def lookup(self, path, name):
        base = path
        while True:
            cand = (base + '/node_modules/' + name) if base else 'node_modules/' + name
            if cand in self.links:
                cand = self.links[cand]
            if cand in self.nodes:
                return cand
            if base == '':
                return None
            i = base.rfind('/node_modules/')
            base = base[:i] if i >= 0 else ''

    def _resolve(self):
        for path, n in self.nodes.items():
            out = {}
            for dep, spec in n['deps'].items():
                t = self.lookup(path, dep)
                if t is not None and t != path:
                    out[dep] = (t, spec)
            self.edges[path] = out
        # direct dependencies = non-root nodes reached from any root
        self.direct = {}
        for r in self.roots:
            for dep, (t, spec) in self.edges[r].items():
                if not self.nodes[t]['root']:
                    self.direct.setdefault(t, []).append((r, spec))
        # reverse edges: target -> [(parent_path, spec)]
        self.parents = {}
        for p, out in self.edges.items():
            for dep, (t, spec) in out.items():
                self.parents.setdefault(t, []).append((p, spec))

    def reach_from(self, start):
        seen, stack = {start}, [start]
        while stack:
            u = stack.pop()
            for _, (t, _) in self.edges.get(u, {}).items():
                if t not in seen and not self.nodes[t]['root']:
                    seen.add(t); stack.append(t)
        return seen

def load(lock_path, pkg_path=None):
    lock = json.load(open(lock_path))
    pkg = json.load(open(pkg_path)) if pkg_path else {}
    return LockGraph(lock, pkg)
