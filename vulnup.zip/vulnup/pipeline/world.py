"""Date-aware view of the npm ecosystem: resolution, advisories and EPSS as they stood on a given date.

All lookups use only information available before `date`:
  * versions published before date (registry_full cache, fetched on demand);
  * advisories published (and not withdrawn) before date;
  * EPSS from data/epss_monthly/epss_scores-<date>.csv.gz when present, otherwise the current
    EPSS file (flagged as look-ahead in `epss_source`).
"""
import gzip, os
import nodesemver
import registry_full as RF
from vulndb import AdvisoryIndex, parse

ADV = AdvisoryIndex()
INFO = {a['id']: a for lst in ADV.idx.values() for a in lst}
_META = {}

def meta(name):
    if name not in _META:
        _META[name] = RF.fetch(name) or {}
    return _META[name]

def prefetch(names, threads=32):
    import concurrent.futures as cf
    todo = [n for n in set(names) if n not in _META]
    with cf.ThreadPoolExecutor(threads) as ex:
        for n, m in zip(todo, ex.map(RF.fetch, todo)):
            _META[n] = m or {}

def split_alias(name, spec):
    s = (spec or '').strip()
    if s.startswith('npm:'):
        body = s[4:]; at = body.rfind('@')
        return (body[:at], body[at + 1:]) if at > 0 else (body, '*')
    return name, s

NON_REGISTRY = ('file:', 'link:', 'git', 'http', 'github:', 'workspace:', 'portal:')

class World:
    def __init__(self, date):
        self.date = date
        self._rel, self._res, self._kids, self._aff, self._clo = {}, {}, {}, {}, {}
        self.epss, self.epss_source = self._load_epss(date)

    # ------------------------------------------------------------ EPSS
    @staticmethod
    def _load_epss(date):
        d = os.path.join('data', 'epss_monthly')
        p = os.path.join(d, f'epss_scores-{date}.csv.gz')
        src = 'dated'
        if not os.path.exists(p):
            # nearest earlier dated file (never later, so no look-ahead); else today's file (flagged)
            earlier = sorted(f for f in (os.listdir(d) if os.path.isdir(d) else [])
                             if f.startswith('epss_scores-') and f[12:22] <= date)
            if earlier:
                p, src = os.path.join(d, earlier[-1]), f'dated ({earlier[-1][12:22]})'
            else:
                p, src = os.path.join('data', 'epss.csv.gz'), 'current (look-ahead)'
        out = {}
        with gzip.open(p, 'rt') as f:
            for line in f:
                if line.startswith('#') or line.startswith('cve,'):
                    continue
                c = line.strip().split(',')
                if len(c) >= 2:
                    try:
                        out[c[0]] = float(c[1])
                    except ValueError:
                        pass
        return out, src

    def epss_of(self, adv_id):
        a = INFO.get(adv_id, {})
        vals = [self.epss[c] for c in a.get('cves', []) if c in self.epss]
        return max(vals) if vals else None

    # ------------------------------------------------------------ versions and resolution
    def released(self, name):
        if name not in self._rel:
            out = []
            for v, (t, _, _) in meta(name).items():
                if t[:10] < self.date:
                    pv = parse(v)
                    if pv is not None:
                        out.append((pv, v))
            out.sort()
            self._rel[name] = out
        return self._rel[name]

    def resolve(self, name, spec):
        name, spec = split_alias(name, spec)
        key = (name, spec)
        if key in self._res:
            return self._res[key]
        res, vs, s = None, self.released(name), spec or '*'
        if vs and not (any(s.startswith(p) for p in NON_REGISTRY) or ('/' in s and s[0] not in '<>=~^')):
            if s in ('latest', '*', 'x'):
                st = [v for pv, v in vs if not pv.prerelease]
                res = (name, st[-1]) if st else None
            else:
                try:
                    rng = nodesemver.make_range(s, loose=True)
                    for pv, v in reversed(vs):
                        if pv.prerelease and '-' not in s:
                            continue
                        if rng.test(nodesemver.make_semver(v, loose=True)):
                            res = (name, v); break
                except Exception:
                    res = None
        self._res[key] = res
        return res

    def children(self, node):
        if node not in self._kids:
            m = meta(node[0]).get(node[1])
            out = []
            if m:
                for deps in (m[1], m[2]):
                    for dn, spec in deps.items():
                        r = self.resolve(dn, spec)
                        if r is not None:
                            out.append(r)
            self._kids[node] = out
        return self._kids[node]

    def expand(self, roots):
        """Prefetch metadata breadth-first so later closures do not fetch one package at a time."""
        frontier, seen = set(roots), set()
        while frontier:
            prefetch({n for n, _ in frontier})
            need = set()
            for node in frontier:
                m = meta(node[0]).get(node[1])
                if m:
                    for deps in (m[1], m[2]):
                        need.update(split_alias(dn, sp)[0] for dn, sp in deps.items())
            prefetch(need)
            seen |= frontier
            frontier = {c for node in frontier for c in self.children(node)} - seen

    def advisories_of(self, node):
        if node not in self._aff:
            self._aff[node] = frozenset(a['id'] for a in ADV.affecting(node[0], node[1], self.date))
        return self._aff[node]

    def closure(self, root):
        if root not in self._clo:
            seen, stack, advs = {root}, [root], set()
            while stack:
                u = stack.pop()
                advs |= self.advisories_of(u)
                for c in self.children(u):
                    if c not in seen:
                        seen.add(c); stack.append(c)
            self._clo[root] = frozenset(advs)
        return self._clo[root]

    def upgrade_options(self, name, cur_version, max_options=8):
        """cur_version first, then newest per major line above it and newest in the current minor line."""
        pc = parse(cur_version)
        if pc is None:
            return [cur_version]
        best = {}
        for pv, v in self.released(name):
            if pv.prerelease or pv < pc:
                continue
            best[('M', pv.major)] = v
            if pv.major == pc.major:
                best[('m', pv.minor)] = v
        picks = {cur_version}
        picks.update(v for k, v in best.items() if k[0] == 'M')
        if ('m', pc.minor) in best:
            picks.add(best[('m', pc.minor)])
        picks = sorted(picks, key=parse)
        if len(picks) > max_options:
            picks = [cur_version] + [p for p in picks if p != cur_version][-(max_options - 1):]
        return picks
