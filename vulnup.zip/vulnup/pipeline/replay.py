"""Monthly historical replay of fleet upgrade planning (Jan 2024 -> Jun 2026).

Each simulated service starts from its real package.json ranges at the start date. Every month t:
  1. the ecosystem is viewed as of t (versions released, advisories published, EPSS on t);
  2. each service is refreshed (ranges re-resolved to the newest in-range versions at t);
  3. the method plans upgrades with only that information, within a monthly fleet budget B;
     chosen upgrades change the dependency's range to ^<new version>;
  4. exposure at t = sum over services of the EPSS x severity x exposure weight of every
     advisory known at t that is still present in the service's tree.
Methods differ only in step 3; every method sees the same world.

usage: python pipeline/replay.py <fleet_size> <seed> [beta] [months] [mode]
output: results/replay/<mode>_n<size>_s<seed>_b<beta>.csv  (one row per month x method)
"""
import csv, json, os, random, sys, time, glob
from collections import defaultdict
sys.path.insert(0, os.path.dirname(__file__))
import vup, fleet
from world import World, INFO
from lockgraph import load
from vulndb import parse
from hindsight import HMAX, KEV

N, SEED = int(sys.argv[1]), int(sys.argv[2])
BETA = float(sys.argv[3]) if len(sys.argv) > 3 else 0.25
MONTHS = int(sys.argv[4]) if len(sys.argv) > 4 else 30
MODE = sys.argv[5] if len(sys.argv) > 5 else 'clustered'
LOOKAHEAD = 3
START = '2024-01-01'
EPSS_FALLBACK = 0.01
L = int(os.environ.get('L', 3))
TL = float(os.environ.get('TL', 30))
OUT = os.environ.get('OUT', os.path.join('results', 'replay')); os.makedirs(OUT, exist_ok=True)

def month_list(start, n):
    y, m = int(start[:4]), int(start[5:7]); out = []
    for _ in range(n):
        out.append(f'{y:04d}-{m:02d}-01'); m += 1
        if m == 13:
            y, m = y + 1, 1
    return out

# ------------------------------------------------------------------ choose the fleet (same rule as run_fleet.py)
insts = [json.load(open(f)) for f in sorted(glob.glob(f'instances/{START}/*.json')) if not os.path.basename(f).startswith('_')]
insts = [i for i in insts if i['decision_deps']]
rng = random.Random(SEED * 1000 + N)
if MODE.startswith('org-'):
    # real fleet: every repository of one GitHub owner that has a lockfile at START (N and SEED are ignored)
    owner = MODE[4:]
    slugs = sorted(os.path.basename(f)[:-len('.lock.json')] for f in glob.glob(f'data/lockfiles/{START}/{owner}__*.lock.json'))
    slugs = [x for x in slugs if os.path.exists(f'data/lockfiles/{START}/{x}.pkg.json')]
    picked = [{'repo': x.replace('__', '/', 1)} for x in slugs]
    N = len(picked)
elif MODE == 'random':
    picked = rng.sample(insts, N)
else:
    pk = [{d['package'] for d in i['decision_deps']} for i in insts]
    order = list(range(len(insts))); rng.shuffle(order)
    chosen = [order[0]]; pool = set(order[1:]); fp = set(pk[order[0]])
    while len(chosen) < N:
        b = max(pool, key=lambda q: (len(pk[q] & fp), rng.random()))
        chosen.append(b); pool.discard(b); fp |= pk[b]
    picked = [insts[q] for q in chosen]
repos = [i['repo'] for i in picked]

def initial_services():
    svcs = []
    for repo in repos:
        slug = repo.replace('/', '__')
        g = load(f'data/lockfiles/{START}/{slug}.lock.json', f'data/lockfiles/{START}/{slug}.pkg.json')
        deps = []
        for path, refs in g.direct.items():
            n = g.nodes[path]
            deps.append({'name': n['name'], 'spec': refs[0][1], 'dev': n['dev'], 'lock': n['version']})
        svcs.append(deps)
    return svcs

# ------------------------------------------------------------------ one month of one method
def current_nodes(W, deps):
    out = []
    for d in deps:
        r = W.resolve(d['name'], d['spec'])
        if r is None and parse(d['lock']) is not None:
            r = (d['name'], d['lock'])          # non-registry spec: frozen at its locked version
        out.append(r)
    return out

def exposure(W, svcs, nodes):
    """Returns (planning exposure with EPSS at t, hindsight exposure with the CVE's peak EPSS over the study,
    exposure to advisories that CISA lists as known exploited). Only the first is visible to planners."""
    tot = hind = kev = 0.0
    for deps, ns in zip(svcs, nodes):
        carried = {}
        for d, nd in zip(deps, ns):
            if nd is None:
                continue
            for a in W.closure(nd):
                carried[a] = carried.get(a, False) or not d['dev']
        for a, prod in carried.items():
            e = W.epss_of(a); s = max(INFO.get(a, {}).get('sev_level', 0), 1) / 4.0
            x = s * (1.0 if prod else vup.DEFAULT['delta_dev'])
            tot += (e if e is not None else EPSS_FALLBACK) * x
            cves = INFO.get(a, {}).get('cves', [])
            hv = [HMAX[c] for c in cves if c in HMAX]
            hind += (max(hv) if hv else EPSS_FALLBACK) * x
            kev += x if any(c in KEV for c in cves) else 0.0
    return tot, hind, kev

def build_insts(W, svcs, nodes):
    out, index = [], []
    for p, (deps, ns) in enumerate(zip(svcs, nodes)):
        dec, idx, advs = [], [], {}
        prod_now = defaultdict(bool)
        for d, nd in zip(deps, ns):
            if nd is not None:
                for a in W.closure(nd):
                    prod_now[a] |= not d['dev']
        for j, (d, nd) in enumerate(zip(deps, ns)):
            if nd is None or not W.closure(nd) or W.resolve(d['name'], d['spec']) is None:
                continue
            pc = parse(nd[1])
            opts = []
            for v in W.upgrade_options(nd[0], nd[1]):
                A = W.closure((nd[0], v)) if v != nd[1] else W.closure(nd)
                pv = parse(v)
                opts.append({'version': v, 'd_major': pv.major - pc.major,
                             'd_minor': (pv.minor - pc.minor) if pv.major == pc.major else None,
                             'advisories': sorted(A)})
                for a in A:
                    if a not in prod_now:
                        prod_now[a] |= not d['dev']
            if len(opts) > 1:
                dec.append({'name': d['name'], 'package': nd[0], 'ref_version': nd[1], 'dev': d['dev'], 'options': opts})
                idx.append(j)
        for dd in dec:
            for o in dd['options']:
                for a in o['advisories']:
                    if a not in advs:
                        e = W.epss_of(a)
                        advs[a] = {'severity': INFO.get(a, {}).get('sev_level', 0),
                                   'epss': e if e is not None else EPSS_FALLBACK,
                                   'kev': False, 'prod': prod_now[a]}
        out.append({'repo': repos[p], 'decision_deps': dec, 'advisories': advs})
        index.append(idx)
    return out, index

def plan_month(method, W, svcs, learned, B):
    nodes = current_nodes(W, [d for deps in svcs for d in deps])
    it = iter(nodes); nodes = [[next(it) for _ in deps] for deps in svcs]
    insts, index = build_insts(W, svcs, nodes)
    if method == 'Refresh only' or not any(i['decision_deps'] for i in insts):
        return []
    F = fleet.Fleet(insts, fcfg=dict(fleet.FCFG, L=L))
    for sv in F.svc:                             # boundaries learned in earlier months are free
        for opts in sv:
            for o in opts:
                o['bounds'] = tuple(b for b in o['bounds'] if b not in learned)
    if method == 'VulnUp-Fleet (look-ahead 3)':
        plan, _ = F.solve(LOOKAHEAD, B, time_limit=TL)
    elif method.startswith('VulnUp-Fleet (look-ahead 3, terminal'):
        plan, _ = F.solve(LOOKAHEAD, B, time_limit=TL, terminal=TERM)
    elif method == 'VulnUp-Fleet (myopic)':
        plan, _ = F.solve(1, B, time_limit=TL)
    elif method == 'Fleet-aware greedy':
        plan = F.ratio_greedy(1, B)
    elif method == 'EPSS-first greedy':
        plan = F.advisory_order_greedy(1, B, key=lambda pa: (-(insts[pa[0]]['advisories'][pa[1]]['epss'] or 0), pa))
    elif method == 'Risk-first greedy':
        # same fixed-order rule, but ranks by the full advisory weight EPSS x severity x exposure
        plan = F.advisory_order_greedy(1, B, key=lambda pa: (-F.w[pa[0]][pa[1]], pa))
    elif method == 'Severity-first greedy':
        plan = F.advisory_order_greedy(1, B, key=lambda pa: (-insts[pa[0]]['advisories'][pa[1]]['severity'], pa))
    acts = []
    for (p, jj), (k, t) in plan.items():
        if t != 1:
            continue
        dd = insts[p]['decision_deps'][jj]
        acts.append((p, index[p][jj], dd['options'][k]['version'], F.svc[p][jj][k]['bounds'],
                     F.svc[p][jj][k]['local'], dd['options'][k]['d_major']))
    return acts

TERM = float(os.environ.get('TERM_W', 6))
METHODS = ([f'VulnUp-Fleet (look-ahead 3, terminal {TERM:g})'] if os.environ.get('TERM_W') else []) + ['VulnUp-Fleet (look-ahead 3)', 'VulnUp-Fleet (myopic)', 'Fleet-aware greedy',
           'EPSS-first greedy', 'Risk-first greedy', 'Severity-first greedy', 'Refresh only']

if __name__ == '__main__':
    B = int(os.environ['BUDGET']) if os.environ.get('BUDGET') else max(1, round(BETA * N))
    if os.environ.get('ONLY'):
        METHODS = [m for m in METHODS if m in os.environ['ONLY'].split('|')] + ['Refresh only']
    state = {m: {'svcs': initial_services(), 'learned': set()} for m in METHODS}
    rows = []
    for t in month_list(START, MONTHS):
        t0 = time.time()
        W = World(t)
        roots = set()
        for m in METHODS:
            for deps in state[m]['svcs']:
                for d in deps:
                    r = W.resolve(d['name'], d['spec']) if d['name'] else None
                    if r: roots.add(r)
        W.expand(roots)
        line = []
        for m in METHODS:
            st = state[m]
            ts = time.time()
            acts = plan_month(m, W, st['svcs'], st['learned'], B)
            secs = time.time() - ts
            spend = 0; newly = set()
            for (p, j, v, bounds, local, dmaj) in acts:
                st['svcs'][p][j]['spec'] = '^' + v
                spend += local + L * len(set(bounds) - st['learned'] - newly); newly |= set(bounds)
            st['learned'] |= newly
            nodes = current_nodes(W, [d for deps in st['svcs'] for d in deps])
            it = iter(nodes); nodes = [[next(it) for _ in deps] for deps in st['svcs']]
            E, EH, EK = exposure(W, st['svcs'], nodes)
            rows.append({'mode': MODE, 'fleet_size': N, 'seed': SEED, 'beta': BETA, 'B': B, 'L': L,
                         'month': t, 'method': m, 'exposure': E, 'exposure_hindsight': EH, 'exposure_kev': EK, 'upgrades': len(acts),
                         'majors': sum(a[5] > 0 for a in acts), 'spend': spend,
                         'over_budget': spend > B, 'plan_seconds': round(secs, 2), 'epss_source': W.epss_source})
            line.append(f'{"".join(w[0] for w in m.split())}={E:.3f}')
        print(t, f'{time.time() - t0:5.0f}s', ' '.join(line), flush=True)
    fn = os.path.join(OUT, f'{MODE}_L{L}_n{N}_s{SEED}_' + (f"B{os.environ['BUDGET']}" if os.environ.get('BUDGET') else f'b{BETA}') + '.csv')
    with open(fn, 'w', newline='') as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    tot = defaultdict(float)
    for r in rows:
        tot[r['method']] += r['exposure']
    ref = tot['Refresh only']
    for m in METHODS:
        print(f'  {m:30s} cumulative exposure {tot[m]:8.3f}  reduction vs refresh {(ref - tot[m]) / ref:6.1%}')
