#!/bin/sh
# Full fleet grid. Results: results/2024-01-01/fleet/*.csv ; log: data/fleet_grid.log
export TL_FULL=30 TL_MYOPIC=8
for MODE in clustered random; do
 for L in 3 8; do
  for N in 25 10 50; do
   case $N in 25) SEEDS="1 2 3 4 5";; *) SEEDS="1 2 3";; esac
   for S in $SEEDS; do
    f=results/2024-01-01/fleet/${MODE}_L${L}_n${N}_s${S}_T4.csv
    [ -f "$f" ] && continue
    FLEET=$MODE L=$L python3 pipeline/run_fleet.py 2024-01-01 $N $S 4 2>&1 | cut -c1-300
   done
  done
 done
done
echo GRID_DONE
