#!/bin/sh
# each line: OUTDIR N SEED BETA MONTHS MODE
while read out n s b mo mode; do
  OUT=$out timeout 7000 python3 pipeline/replay.py $n $s $b $mo $mode > $out/${mode}_s${s}.log 2>&1
  echo "done $mode s$s rc=$?"
done
