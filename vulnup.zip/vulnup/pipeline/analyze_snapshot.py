"""Feasibility check: what a maintainer faced on the snapshot date.

For every installed package version in each project's lockfile, find advisories
known on that date, then classify each vulnerable node:
  refresh       - an unaffected version, released by the date, satisfies every
                  dependent's declared range (fixable by a lockfile refresh alone)
  needs-upgrade - an unaffected version exists but lies outside some dependent's
                  range, so a parent (ultimately a direct dependency) must change
  no-fix        - no unaffected version >= current had been released by the date
and count how many direct dependencies can reach it ("carriers").

usage: python pipeline/analyze_snapshot.py 2024-01-01
output: results/<date>/nodes.csv, projects.csv, summary.json
"""
import csv, json, os, sys, statistics, concurrent.futures as cf
from collections import Counter
sys.path.insert(0, os.path.dirname(__file__))
from lockgraph import load
from vulndb import AdvisoryIndex, Registry, parse, satisfies, is_semver_spec

DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
SNAP = os.path.join(os.environ.get('LOCKDIR', os.path.join('data', 'lockfiles')), DATE)
OUT = os.path.join(os.environ.get('RESULTS', 'results'), DATE); os.makedirs(OUT, exist_ok=True)
adv, reg = AdvisoryIndex(), Registry()

def candidates(name, cur):
    """Versions released before DATE, >= current, stable, affected by no advisory known at DATE."""
    cv = parse(cur); out = []
    for v, t in reg.times(name).items():
        pv = parse(v)
        if pv is None or pv.prerelease or t[:10] >= DATE or (cv is not None and pv < cv):
            continue
        if not adv.affecting(name, v, DATE):
            out.append(v)
    return out

# Deliberately vulnerable training apps would distort the picture of real projects.
EXCLUDE = {'OWASP/NodeGoat'}
projects = [r for r in csv.DictReader(open(os.path.join(SNAP, 'index.csv')))
            if r['status'] == 'ok' and r['repo'] not in EXCLUDE]

_aff = {}
def affecting(name, version):
    k = (name, version)
    if k not in _aff:
        _aff[k] = adv.affecting(name, version, DATE)
    return _aff[k]

_cand = {}
def candidates_cached(name, cur):
    k = (name, cur)
    if k not in _cand:
        _cand[k] = candidates(name, cur)
    return _cand[k]

def load_project(repo):
    slug = repo.replace('/', '__')
    try:
        return load(os.path.join(SNAP, slug + '.lock.json'), os.path.join(SNAP, slug + '.pkg.json'))
    except Exception:
        return None      # malformed lockfile (e.g. merge-conflict markers); counted below

# pass 1: vulnerable package names only (graphs are not kept, to bound memory)
names, unparsable = set(), []
for p in projects:
    g = load_project(p['repo'])
    if g is None:
        unparsable.append(p['repo']); continue
    for path, n in g.nodes.items():
        if not n['root'] and affecting(n['name'], n['version']):
            names.add(n['name'])
projects = [p for p in projects if p['repo'] not in set(unparsable)]
print(f'{len(projects)} projects parsed, {len(unparsable)} unparsable, {len(names)} vulnerable package names', flush=True)

# prefetch registry metadata for vulnerable package names
with cf.ThreadPoolExecutor(16) as ex:
    list(ex.map(reg.times, sorted(names)))

node_rows, proj_rows = [], []
for p in projects:
    repo = p['repo']
    g = load_project(repo)
    vuln = {path: affecting(n['name'], n['version']) for path, n in g.nodes.items() if not n['root']}
    vuln = {k: v for k, v in vuln.items() if v}
    reach = {d: g.reach_from(d) for d in g.direct} if vuln else {}
    rows = []
    for path, advs in vuln.items():
        n = g.nodes[path]
        cands = candidates_cached(n['name'], n['version'])
        specs = [spec for _, spec in g.parents.get(path, [])]
        if not cands:
            cls = 'no-fix'
        elif all(is_semver_spec(s) for s in specs) and any(all(satisfies(v, s) for s in specs) for v in cands):
            cls = 'refresh'
        else:
            cls = 'needs-upgrade'
        carriers = sorted({g.nodes[d]['name'] for d, R in reach.items() if path in R})
        rows.append({
            'repo': repo, 'path': path, 'package': n['name'], 'version': n['version'],
            'dev_only': n['dev'], 'is_direct': path in g.direct,
            'n_advisories': len(advs), 'max_severity': max(a['sev_level'] for a in advs),
            'kev': any(a['kev'] for a in advs), 'advisories': ' '.join(a['id'] for a in advs),
            'max_epss': max((a['epss'] for a in advs if a.get('epss') is not None), default=''),
            'class': cls, 'n_carriers': len(carriers), 'carriers': ' '.join(carriers),
        })
    node_rows += rows
    proj_rows.append({
        'repo': repo, 'nodes': sum(1 for x in g.nodes.values() if not x['root']),
        'direct_deps': len(g.direct), 'vulnerable_nodes': len(rows),
        'vulnerable_prod_nodes': sum(1 for r in rows if not r['dev_only']),
        'needs_upgrade': sum(r['class'] == 'needs-upgrade' for r in rows),
        'refresh': sum(r['class'] == 'refresh' for r in rows),
        'no_fix': sum(r['class'] == 'no-fix' for r in rows),
        'direct_deps_implicated': len({c for r in rows if r['class'] == 'needs-upgrade' for c in r['carriers'].split()}),
    })

def write(fn, rows):
    with open(os.path.join(OUT, fn), 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
write('nodes.csv', node_rows); write('projects.csv', proj_rows)

trans = [r for r in node_rows if not r['is_direct']]
cls = Counter(r['class'] for r in node_rows)
summary = {
    'snapshot_date': DATE, 'projects': len(proj_rows), 'unparsable_lockfiles': len(unparsable),
    'median_nodes': statistics.median(p['nodes'] for p in proj_rows),
    'median_direct_deps': statistics.median(p['direct_deps'] for p in proj_rows),
    'projects_with_vulnerable_node': sum(p['vulnerable_nodes'] > 0 for p in proj_rows),
    'projects_with_needs_upgrade': sum(p['needs_upgrade'] > 0 for p in proj_rows),
    'vulnerable_nodes': len(node_rows),
    'vulnerable_prod_nodes': sum(not r['dev_only'] for r in node_rows),
    'class_counts': dict(cls),
    'class_share': {k: round(v / len(node_rows), 3) for k, v in cls.items()},
    'severity_counts': dict(Counter(r['max_severity'] for r in node_rows)),
    'kev_nodes': sum(r['kev'] for r in node_rows),
    'transitive_vulnerable_nodes': len(trans),
    'carrier_hist_transitive': {
        '1': sum(r['n_carriers'] == 1 for r in trans),
        '2-5': sum(2 <= r['n_carriers'] <= 5 for r in trans),
        '6+': sum(r['n_carriers'] >= 6 for r in trans),
        '0 (unreached)': sum(r['n_carriers'] == 0 for r in trans)},
    'median_direct_deps_implicated_per_project_with_needs_upgrade':
        statistics.median([p['direct_deps_implicated'] for p in proj_rows if p['needs_upgrade']] or [0]),
}
json.dump(summary, open(os.path.join(OUT, 'summary.json'), 'w'), indent=1)
print(json.dumps(summary, indent=1))
