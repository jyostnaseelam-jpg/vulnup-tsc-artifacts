"""Fleet experiments: random fleets of services drawn from the instance sample.

usage: python pipeline/run_fleet.py <date> <fleet_size> <seed> [T] [budgets per service, comma-sep]
output: results/<date>/fleet/n<size>_s<seed>.csv (one row per budget x method)
"""
import csv, glob, json, os, random, sys, time
sys.path.insert(0, os.path.dirname(__file__))
import fleet, vup

DATE, N, SEED = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
T = int(sys.argv[4]) if len(sys.argv) > 4 else 4
BETAS = [float(b) for b in (sys.argv[5] if len(sys.argv) > 5 else '0.25,0.5,1').split(',')]
ADDON = os.environ.get('ADDON') == '1'
TL_FULL = float(os.environ.get('TL_FULL', 60)); TL_MYOPIC = float(os.environ.get('TL_MYOPIC', 15))
OUT = os.path.join('results', DATE, 'fleet'); os.makedirs(OUT, exist_ok=True)

files = sorted(f for f in glob.glob(os.path.join('instances', DATE, '*.json')) if not os.path.basename(f).startswith('_'))
insts = []
for f in files:
    inst = json.load(open(f))
    deps, w = vup.prepare(inst)
    if deps and vup.risk_of(deps, w, [0] * len(deps)) > 0:
        insts.append(inst)
MODE = os.environ.get('FLEET', 'random')            # random | clustered
L = int(os.environ.get('L', fleet.FCFG['L']))
EPSS_DATE = os.environ.get('EPSS_DATE')          # e.g. 2024-01-01: use EPSS as published on that date
if EPSS_DATE:
    from world import World
    _W = World(EPSS_DATE)
    for inst in insts:
        for u, a in inst['advisories'].items():
            a['epss'] = _W.epss_of(u)
    OUT = os.path.join('results', DATE, 'fleet_epss' + EPSS_DATE); os.makedirs(OUT, exist_ok=True)
rng = random.Random(SEED * 1000 + N)
if MODE == 'random':
    picked = rng.sample(insts, N)
else:
    # stack-similar fleet: start from a random service, repeatedly add the service sharing the most
    # decision packages with the fleet so far (ties broken randomly) -- a proxy for one organisation's stack
    pk = [{d['package'] for d in i['decision_deps']} for i in insts]
    order = list(range(len(insts))); rng.shuffle(order)
    chosen = [order[0]]; pool = set(order[1:]); fleet_pk = set(pk[order[0]])
    while len(chosen) < N:
        best = max(pool, key=lambda q: (len(pk[q] & fleet_pk), rng.random()))
        chosen.append(best); pool.discard(best); fleet_pk |= pk[best]
    picked = [insts[q] for q in chosen]
F = fleet.Fleet(picked, fcfg=dict(fleet.FCFG, L=L))
r0 = F.risk_state({})
shared = sum(1 for b in {b for (p, j) in F.deps for o in F.svc[p][j] for b in o['bounds']}
             if len({p for (p, j) in F.deps if any(b in o['bounds'] for o in F.svc[p][j])}) > 1)

rows = []
for beta in BETAS:
    B = max(1, round(beta * N))
    methods = {}
    if ADDON:
        t = time.time(); methods['Risk-first greedy'] = (F.advisory_order_greedy(
            T, B, key=lambda pa: (-F.w[pa[0]][pa[1]], pa)), time.time() - t, {})
        methods['Refresh only'] = ({}, 0, {})
    else:
     t = time.time(); plan, info = F.solve(T, B, time_limit=TL_FULL); methods['VulnUp-Fleet'] = (plan, time.time() - t, info)
     t = time.time(); methods['Myopic sprint-optimal'] = (F.myopic_sprint_optimal(T, B, TL_MYOPIC), time.time() - t, {})
     t = time.time(); methods['Ratio greedy + waves'] = (F.ratio_greedy(T, B, waves=True), time.time() - t, {})
     t = time.time(); methods['Ratio greedy'] = (F.ratio_greedy(T, B), time.time() - t, {})
     t = time.time(); methods['EPSS-first greedy'] = (F.advisory_order_greedy(
         T, B, key=lambda pa: (-(picked[pa[0]]['advisories'][pa[1]]['epss'] or 0), pa)), time.time() - t, {})
     t = time.time(); methods['Severity-first greedy'] = (F.advisory_order_greedy(
         T, B, key=lambda pa: (-picked[pa[0]]['advisories'][pa[1]]['severity'], pa)), time.time() - t, {})
     methods['Refresh only'] = ({}, 0, {})
    for name, (plan, secs, info) in methods.items():
        E, spend, ok = F.evaluate(plan, T, B)
        learned = {b for (p, j), (k, _) in plan.items() for b in F.svc[p][j][k]['bounds']}
        rows.append({'mode': MODE, 'L': L, 'fleet_size': N, 'seed': SEED, 'T': T, 'beta': beta, 'B': B, 'method': name,
                     'exposure': E, 'exposure_ref': T * r0, 'reduction': (T * r0 - E) / (T * r0),
                     'feasible': ok, 'upgrades': len(plan), 'boundaries_learned': len(learned),
                     'seconds': round(secs, 2), 'status': info.get('status', ''),
                     'bound': info.get('bound', ''), 'services': N, 'decision_deps': len(F.deps),
                     'shared_boundaries': shared})
    best = rows[-len(methods)]
    print(f"{MODE} L={L:g} n={N} seed={SEED} beta={beta} B={B}: " + ', '.join(
        f"{r['method']} {r['reduction']:.1%}" for r in rows[-len(methods):]) + f" [{best['status']}]", flush=True)

fn = os.path.join(OUT, f'{MODE}_L{L:g}_n{N}_s{SEED}_T{T}.csv')
if ADDON:   # merge the extra baseline into the existing results file
    new = {r['method'] for r in rows} - {'Refresh only'}
    old = list(csv.DictReader(open(fn)))
    ref = {(r['beta'], r['method']): r for r in old}
    for r in rows:   # sanity check: the reconstructed fleet must reproduce the stored reference exposure
        if r['method'] == 'Refresh only':
            assert abs(float(ref[(str(r['beta']), 'Refresh only')]['exposure']) - r['exposure']) < 1e-9, 'fleet mismatch'
    rows = [r for r in old if r['method'] not in new] + [{k: r.get(k, '') for k in old[0]} for r in rows if r['method'] in new]
with open(fn, 'w', newline='') as fh:
    wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)
