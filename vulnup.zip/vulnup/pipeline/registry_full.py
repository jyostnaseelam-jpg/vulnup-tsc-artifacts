"""Compact npm registry metadata: per package, {version: [publish_time, dependencies, optionalDependencies]}.

Fetches the full packument once per package, keeps only what resolution needs,
and caches it gzip-compressed in data/registry_full/.
"""
import gzip, json, os, threading, urllib.parse
import requests

CACHE = os.path.join('data', 'registry_full')
os.makedirs(CACHE, exist_ok=True)
_local = threading.local()

def _session():
    if not hasattr(_local, 's'):
        _local.s = requests.Session()
    return _local.s

def _path(name):
    return os.path.join(CACHE, urllib.parse.quote(name, safe='') + '.json.gz')

def fetch(name):
    """Return compact metadata for a package (fetching it if not cached). {} if it does not exist."""
    fp = _path(name)
    if os.path.exists(fp):
        with gzip.open(fp, 'rt') as f:
            return json.load(f)
    url = 'https://registry.npmjs.org/' + urllib.parse.quote(name, safe='@')
    out = {}
    for attempt in range(3):
        try:
            r = _session().get(url, timeout=180)
            if r.status_code == 404:
                break
            r.raise_for_status()
            doc = r.json()
            times = doc.get('time') or {}
            for v, m in (doc.get('versions') or {}).items():
                if v in times:
                    out[v] = [times[v], m.get('dependencies') or {}, m.get('optionalDependencies') or {}]
            break
        except Exception:
            if attempt == 2:
                return None          # transient failure: not cached, caller may retry later
    with gzip.open(fp, 'wt') as f:
        json.dump(out, f)
    return out

def cached(name):
    return os.path.exists(_path(name))
