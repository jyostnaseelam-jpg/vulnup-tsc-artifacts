"""Find public GitHub repos that commit an npm package-lock.json at their root.

Checks raw.githubusercontent.com (no API token needed) on the main and master
branches. Output: data/candidates.csv with repo, branch, lockfileVersion.
"""
import csv, json, sys, concurrent.futures as cf
import requests

CANDIDATES = """
microsoft/vscode microsoft/TypeScript microsoft/playwright nestjs/nest typeorm/typeorm
mongodb/node-mongodb-native socketio/socket.io axios/axios jitsi/jitsi-meet bitwarden/clients
Kong/insomnia parse-community/parse-server node-red/node-red puppeteer/puppeteer firebase/firebase-tools
mozilla/pdf.js brave/brave-browser brave/brave-core louislam/uptime-kuma jellyfin/jellyfin-web
wekan/wekan overleaf/overleaf tutao/tutanota nextcloud/server Leaflet/Leaflet openlayers/openlayers
plotly/plotly.js highlightjs/highlight.js markedjs/marked jquery/jquery twbs/bootstrap quilljs/quill
videojs/video.js apollographql/apollo-client apollographql/apollo-server graphql/graphql-js
sidorares/node-mysql2 redis/node-redis winstonjs/winston nodemailer/nodemailer helmetjs/helmet
tj/commander.js mochajs/mocha karma-runner/karma rollup/rollup stylelint/stylelint remy/nodemon
npm/cli apache/echarts OWASP/NodeGoat google/zx docsifyjs/docsify zadam/trilium CesiumGS/cesium
ionic-team/capacitor mozilla/addons-frontend Unitech/pm2 knex/knex moment/moment iamkun/dayjs
ramda/ramda auth0/node-jsonwebtoken expressjs/multer ajv-validator/ajv yargs/yargs less/less.js
gulpjs/gulp gruntjs/grunt jasmine/jasmine chalk/chalk node-fetch/node-fetch sampotts/plyr
summernote/summernote select2/select2 FortAwesome/Font-Awesome Chart.js/Chart.js chartjs/Chart.js
mattermost/mattermost-webapp TryGhost/Ghost RocketChat/Rocket.Chat standardnotes/app
Budibase/budibase ToolJet/ToolJet appsmithorg/appsmith outline/outline calcom/cal.com
medusajs/medusa nodejs/nodejs.org bpmn-io/bpmn-js keystonejs/keystone sequelize/sequelize
Automattic/mongoose serverless/serverless juice-shop/juice-shop botpress/botpress
cypress-io/cypress GoogleChrome/lighthouse webtorrent/webtorrent marktext/marktext
laurent22/joplin mastodon/mastodon mdn/content mdn/yari home-assistant/frontend Chocobozzz/PeerTube
metabase/metabase ether/etherpad-lite zulip/zulip electron/electron electron/fiddle vercel/hyper
logseq/logseq ProtonMail/WebClients owncloud/web d3/d3 tinymce/tinymce ckeditor/ckeditor5
date-fns/date-fns immerjs/immer reduxjs/redux mobxjs/mobx prisma/prisma brianc/node-postgres
pinojs/pino jaredhanson/passport sindresorhus/got babel/babel parcel-bundler/parcel postcss/postcss
verdaccio/verdaccio webpack/webpack eslint/eslint prettier/prettier facebook/react expressjs/express
fastify/fastify koajs/koa hapijs/hapi strapi/strapi directus/directus n8n-io/n8n nocodb/nocodb
excalidraw/excalidraw hoppscotch/hoppscotch mermaid-js/mermaid jestjs/jest vitejs/vite
angular/angular-cli angular/components aws/aws-cdk aws-amplify/amplify-js expo/expo
signalapp/Signal-Desktop PostHog/posthog getsentry/sentry grafana/grafana elastic/kibana
openai/openai-node anthropics/anthropic-sdk-typescript googleapis/google-api-nodejs-client
Azure/azure-sdk-for-js microsoft/fluentui microsoft/botframework-sdk microsoft/BotFramework-WebChat
microsoft/vscode-extension-samples microsoft/monaco-editor microsoft/vscode-js-debug
microsoft/azuredatastudio microsoft/ApplicationInsights-JS microsoft/rushstack
GoogleChrome/workbox google/blockly Kong/kong-manager bigbluebutton/bigbluebutton
discourse/discourse freeCodeCamp/freeCodeCamp DIYgod/RSSHub immich-app/immich
""".split()

def probe(repo):
    for branch in ('main', 'master'):
        url = f'https://raw.githubusercontent.com/{repo}/{branch}/package-lock.json'
        try:
            r = requests.get(url, timeout=30, stream=True)
            if r.status_code != 200:
                continue
            head = r.raw.read(400).decode('utf-8', 'ignore')
            r.close()
            ver = ''
            if '"lockfileVersion"' in head:
                ver = head.split('"lockfileVersion"')[1].split(',')[0].strip(': \n')
            return repo, branch, ver
        except Exception as e:
            print('ERR', repo, e, file=sys.stderr)
    return repo, '', ''

if __name__ == '__main__':
    repos = list(dict.fromkeys(CANDIDATES))
    with cf.ThreadPoolExecutor(16) as ex:
        res = list(ex.map(probe, repos))
    found = [r for r in res if r[1]]
    with open('data/candidates.csv', 'w', newline='') as f:
        w = csv.writer(f); w.writerow(['repo', 'branch', 'lockfileVersion']); w.writerows(found)
    print(f'{len(repos)} probed, {len(found)} have a root package-lock.json')
