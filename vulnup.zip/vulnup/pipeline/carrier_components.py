"""Size of the coupled subproblems.

Build, per project, a graph over direct dependencies: two direct deps are linked
when some needs-upgrade vulnerable node is reachable from both. Each connected
component must be optimized jointly; singletons decompose into a multiple-choice
knapsack. Reports the component-size distribution.
"""
import csv, json, sys, collections
DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
rows = [r for r in csv.DictReader(open(f'results/{DATE}/nodes.csv')) if r['class'] == 'needs-upgrade']
by_repo = collections.defaultdict(list)
for r in rows:
    by_repo[r['repo']].append(r['carriers'].split() or [r['package']])  # a direct node is its own carrier

sizes, largest = [], {}
for repo, sets in by_repo.items():
    parent = {}
    def find(a):
        parent.setdefault(a, a)
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    for s in sets:
        for c in s:
            find(c)
        for c in s[1:]:
            parent[find(c)] = find(s[0])
    comp = collections.Counter(find(c) for c in parent)
    sizes += list(comp.values()); largest[repo] = max(comp.values())

hist = collections.Counter('1' if s == 1 else '2' if s == 2 else '3-5' if s <= 5 else '6-10' if s <= 10 else '11+' for s in sizes)
out = {'components': len(sizes), 'size_hist': dict(hist),
       'largest_component_per_project': sorted(largest.values()),
       'projects_with_largest_le_5': sum(v <= 5 for v in largest.values()), 'projects': len(largest)}
json.dump(out, open(f'results/{DATE}/components.json', 'w'), indent=1)
print(json.dumps(out, indent=1))
