"""Scalability summary: stack-similar fleets, L=3, dated EPSS (results/2024-01-01/fleet_epss2024-01-01)."""
import csv, glob, statistics as st
D = 'results/2024-01-01/fleet_epss2024-01-01'
for n in (10, 25, 50, 100, 200):
    rows = [r for f in glob.glob(f'{D}/clustered_L3_n{n}_s*_T4.csv') for r in csv.DictReader(open(f))]
    if not rows:
        continue
    vu = [r for r in rows if r['method'] == 'VulnUp-Fleet']
    by = {}
    for r in rows:
        by.setdefault((r['seed'], r['beta']), {})[r['method']] = r
    g_e = [float(v['VulnUp-Fleet']['reduction']) - float(v['EPSS-first greedy']['reduction']) for v in by.values()]
    g_w = [float(v['VulnUp-Fleet']['reduction']) - float(v['Ratio greedy + waves']['reduction']) for v in by.values()]
    t = [float(r['seconds']) for r in vu]
    tw = [float(v['Ratio greedy + waves']['seconds']) for v in by.values()]
    print(f"n={n:3d} cases={len(vu):2d} dec_deps_med={st.median(int(r['decision_deps']) for r in vu):5.0f} "
          f"optimal={sum(r['status'] == 'optimal' for r in vu)}/{len(vu)} time_med={st.median(t):6.1f}s max={max(t):6.1f}s "
          f"greedy_time_med={st.median(tw):5.1f}s gain_vs_EPSS={st.mean(g_e):+.1%} gain_vs_greedy={st.mean(g_w):+.1%} "
          f"worse_than_greedy={sum(x < -1e-9 for x in g_w)}")
