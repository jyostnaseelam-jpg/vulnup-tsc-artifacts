"""Turn project snapshots into VUP optimization instances.

For a sampled project at date t:
  * every direct dependency i is resolved the way `npm install` would resolve it at t:
    its root range -> newest released version that satisfies it (v_ref, the "refreshed"
    current version), then recursively each dependency range -> newest satisfying release;
  * A(i@v) = advisories known at t that affect any package in the resolved subtree;
  * decision dependencies = those whose A(i@v_ref) is non-empty;
  * candidate versions = v_ref plus the newest release of every major line >= v_ref's
    (and the newest in v_ref's own minor/major lines), all released before t.

usage: python pipeline/build_instances.py <date> <n_projects> [seed]
output: instances/<date>/<owner>__<repo>.json, instances/<date>/_stats.json, _fidelity.json
"""
import csv, json, os, random, sys, time, concurrent.futures as cf
from collections import defaultdict
sys.path.insert(0, os.path.dirname(__file__))
import nodesemver
from lockgraph import load
from vulndb import AdvisoryIndex, parse
import registry_full as RF

DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
N = int(sys.argv[2]) if len(sys.argv) > 2 else 500
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 42
MAX_OPTIONS = 8
OUT = os.path.join('instances', DATE); os.makedirs(OUT, exist_ok=True)
adv = AdvisoryIndex()

# ---------------------------------------------------------------- registry access
META = {}
def ensure(names, threads=32):
    todo = [n for n in set(names) if n not in META]
    if not todo:
        return
    with cf.ThreadPoolExecutor(threads) as ex:
        for n, m in zip(todo, ex.map(RF.fetch, todo)):
            META[n] = m or {}

_ver_cache = {}
def released(name):
    """Stable and prerelease versions released before DATE, as (parsed, string) sorted."""
    if name not in _ver_cache:
        out = []
        for v, (t, _, _) in META.get(name, {}).items():
            if t[:10] < DATE:
                pv = parse(v)
                if pv is not None:
                    out.append((pv, v))
        out.sort()
        _ver_cache[name] = out
    return _ver_cache[name]

def split_alias(name, spec):
    s = (spec or '').strip()
    if s.startswith('npm:'):
        body = s[4:]
        at = body.rfind('@')
        if at > 0:
            return body[:at], body[at + 1:]
        return body, '*'
    return name, s

_res_cache = {}
def resolve(name, spec):
    """Newest version released before DATE satisfying spec (npm semantics). None if not resolvable."""
    name, spec = split_alias(name, spec)
    key = (name, spec)
    if key in _res_cache:
        return _res_cache[key]
    vs = released(name)
    res = None
    if vs:
        s = spec or '*'
        if s in ('latest', '*', '', 'x'):
            stable = [v for pv, v in vs if not pv.prerelease]
            res = (name, stable[-1]) if stable else None
        elif any(s.startswith(p) for p in ('file:', 'link:', 'git', 'http', 'github:', 'workspace:', 'portal:')) or ('/' in s and not s[0] in '<>=~^'):
            res = None
        else:
            try:
                rng = nodesemver.make_range(s, loose=True)
                for pv, v in reversed(vs):
                    if pv.prerelease and '-' not in s:
                        continue
                    if rng.test(nodesemver.make_semver(v, loose=True)):
                        res = (name, v); break
            except Exception:
                res = None
    _res_cache[key] = res
    return res

def children(node):
    name, v = node
    m = META.get(name, {}).get(v)
    if not m:
        return []
    out = []
    for deps in (m[1], m[2]):
        for dn, spec in deps.items():
            r = resolve(dn, spec)
            if r is not None:
                out.append(r)
    return out

def expand(roots):
    """Fetch metadata level by level until every node reachable from roots is known."""
    frontier, seen = set(roots), set()
    while frontier:
        ensure({n for n, _ in frontier})
        nxt = set()
        needed = set()
        for node in frontier:
            seen.add(node)
            m = META.get(node[0], {}).get(node[1])
            if m:
                for deps in (m[1], m[2]):
                    for dn, spec in deps.items():
                        needed.add(split_alias(dn, spec)[0])
        ensure(needed)
        for node in frontier:
            for c in children(node):
                if c not in seen:
                    nxt.add(c)
        frontier = nxt - seen

_aff = {}
def node_advisories(node):
    if node not in _aff:
        _aff[node] = tuple(a['id'] for a in adv.affecting(node[0], node[1], DATE))
    return _aff[node]

ADV_INFO = {}
for name, lst in adv.idx.items():
    for a in lst:
        ADV_INFO[a['id']] = a

_clo = {}
def closure(root):
    """(advisory ids in the resolved subtree of root, subtree size)."""
    if root in _clo:
        return _clo[root]
    seen, stack, advs = {root}, [root], set()
    while stack:
        u = stack.pop()
        advs.update(node_advisories(u))
        for c in children(u):
            if c not in seen:
                seen.add(c); stack.append(c)
    _clo[root] = (frozenset(advs), len(seen))
    return _clo[root]

def options_for(name, v_ref):
    pref = parse(v_ref)
    stable = [(pv, v) for pv, v in released(name) if not pv.prerelease and pv >= pref]
    best = {}
    for pv, v in stable:                      # newest per major line (and per minor within v_ref's major)
        best[('M', pv.major)] = v
        if pv.major == pref.major:
            best[('m', pv.minor)] = v
    picks = {v_ref}
    majors = sorted({k[1] for k in best if k[0] == 'M'})
    for M in majors:
        picks.add(best[('M', M)])
    if ('m', pref.minor) in best:
        picks.add(best[('m', pref.minor)])
    picks = sorted(picks, key=parse)
    if len(picks) > MAX_OPTIONS:                # keep v_ref and the newest options
        picks = [v_ref] + [p for p in picks if p != v_ref][-(MAX_OPTIONS - 1):]
    return picks

# ---------------------------------------------------------------- sample
proj = [r for r in csv.DictReader(open(os.path.join('results', DATE, 'projects.csv'))) if int(r['needs_upgrade']) > 0]
random.Random(SEED).shuffle(proj)
sample = proj[:N]
SNAP = os.path.join('data', 'lockfiles', DATE)
t0 = time.time()

graphs, directs = {}, {}
for p in sample:
    slug = p['repo'].replace('/', '__')
    g = load(os.path.join(SNAP, slug + '.lock.json'), os.path.join(SNAP, slug + '.pkg.json'))
    deps = {}
    for path, refs in g.direct.items():
        n = g.nodes[path]
        name = n['name']
        spec = refs[0][1]
        deps[name] = {'spec': spec, 'lock_version': n['version'], 'dev': n['dev']}
    directs[p['repo']] = deps
    graphs[p['repo']] = g
print(f'{len(sample)} projects loaded', flush=True)

# resolve v_ref for every direct dependency, then expand their subtrees
ensure({split_alias(n, d['spec'])[0] for deps in directs.values() for n, d in deps.items()})
for repo, deps in directs.items():
    for name, d in deps.items():
        r = resolve(name, d['spec'])
        if r is None and parse(d['lock_version']) is not None:
            r = (name, d['lock_version'])
        d['ref'] = r
roots = {d['ref'] for deps in directs.values() for d in deps.values() if d['ref']}
expand(roots)
print(f'refs expanded: {len(META)} packages known, {time.time() - t0:.0f}s', flush=True)

# candidate options for decision dependencies
opt_roots = set()
for repo, deps in directs.items():
    for name, d in deps.items():
        if d['ref'] and closure(d['ref'])[0]:
            d['options'] = [(d['ref'][0], v) for v in options_for(d['ref'][0], d['ref'][1])]
            opt_roots.update(d['options'])
expand(opt_roots)
print(f'options expanded: {len(META)} packages known, {time.time() - t0:.0f}s', flush=True)

# ---------------------------------------------------------------- write instances + fidelity
nodes_csv = defaultdict(list)
for r in csv.DictReader(open(os.path.join('results', DATE, 'nodes.csv'))):
    nodes_csv[r['repo']].append(r)

stats = defaultdict(list); fid = defaultdict(int)
for repo, deps in directs.items():
    dec = []
    for name, d in deps.items():
        if 'options' not in d:
            continue
        pref = parse(d['ref'][1])
        opts = []
        for pkg, v in d['options']:
            a, size = closure((pkg, v))
            pv = parse(v)
            opts.append({'version': v, 'd_major': pv.major - pref.major,
                         'd_minor': (pv.minor - pref.minor) if pv.major == pref.major else None,
                         'released': META.get(pkg, {}).get(v, [''])[0][:10], 'advisories': sorted(a), 'subtree_size': size})
        dec.append({'name': name, 'package': d['ref'][0], 'spec': d['spec'], 'lock_version': d['lock_version'],
                    'ref_version': d['ref'][1], 'dev': d['dev'], 'options': opts})
    carried = defaultdict(set)
    for dd in dec:
        for o in dd['options']:
            for a in o['advisories']:
                carried[a].add(dd['name'])
    ref_advs = {a for dd in dec for a in dd['options'][0]['advisories']}
    advisories = {}
    for a in carried:
        info = ADV_INFO.get(a, {})
        prod = any(not dd['dev'] and a in dd['options'][0]['advisories'] for dd in dec)
        advisories[a] = {'severity': info.get('sev_level', 0), 'epss': info.get('epss'),
                         'kev': info.get('kev', False), 'prod': prod,
                         'carriers': sorted(carried[a]), 'in_reference_state': a in ref_advs}
    inst = {'repo': repo, 'date': DATE, 'decision_deps': dec, 'advisories': advisories,
            'n_direct_deps': len(deps)}
    json.dump(inst, open(os.path.join(OUT, repo.replace('/', '__') + '.json'), 'w'))

    # stats
    stats['decision_deps'].append(len(dec))
    stats['options_per_dep'] += [len(dd['options']) for dd in dec]
    stats['ref_advisories'].append(len(ref_advs))
    removable = {a for a in ref_advs if all(any(a not in o['advisories'] for o in dd['options'])
                                           for dd in dec if a in dd['options'][0]['advisories'])}
    stats['removable_share'].append(len(removable) / len(ref_advs) if ref_advs else None)
    # fidelity vs lockfile classification
    # advisory level: an advisory with any needs-upgrade/no-fix copy in the lockfile should survive a
    # full refresh; one whose every copy is refresh-fixable should disappear.
    cls_by_adv = defaultdict(set)
    for r in nodes_csv[repo]:
        for a in r['advisories'].split():
            cls_by_adv[a].add(r['class'])
    for a, classes in cls_by_adv.items():
        k = 'refresh_only' if classes == {'refresh'} else 'needs_upgrade_or_nofix'
        fid[k + '_total'] += 1
        fid[k + '_in_ref'] += a in ref_advs

json.dump(dict(fid), open(os.path.join(OUT, '_fidelity.json'), 'w'), indent=1)
import statistics as st
summary = {
    'projects': len(directs), 'packages_fetched': len(META), 'seconds': round(time.time() - t0),
    'decision_deps_median': st.median(stats['decision_deps']), 'decision_deps_max': max(stats['decision_deps']),
    'options_per_dep_median': st.median(stats['options_per_dep']),
    'ref_advisories_median': st.median(stats['ref_advisories']),
    'projects_with_ref_advisories': sum(x > 0 for x in stats['ref_advisories']),
    'removable_share_median': st.median([x for x in stats['removable_share'] if x is not None]),
    'fidelity': {k: v for k, v in fid.items()},
}
json.dump(summary, open(os.path.join(OUT, '_stats.json'), 'w'), indent=1)
print(json.dumps(summary, indent=1))
