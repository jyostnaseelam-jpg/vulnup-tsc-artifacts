"""Build the project corpus with GitHub's search API. Run this on YOUR machine.

Selects JavaScript/TypeScript repositories that are not forks or archived,
have >= 500 stars, were created before 2023 and were still active after
1 Jan 2024, then keeps those with a package-lock.json at the repo root on
their default branch. Deliberately vulnerable training apps are dropped.

usage:
    export GITHUB_TOKEN=...        # fine-grained, public repositories only, no extra permissions
    pip install requests
    python find_repos.py           # writes candidates.csv (send this file back)

Takes roughly 10-20 minutes because of search rate limits.
"""
import csv, os, re, sys, time
import requests

TOKEN = os.environ.get('GITHUB_TOKEN')
if not TOKEN:
    sys.exit('Set GITHUB_TOKEN first.')
API = requests.Session()
API.headers.update({'Authorization': f'Bearer {TOKEN}', 'Accept': 'application/vnd.github+json',
                    'X-GitHub-Api-Version': '2022-11-28'})
RAW = requests.Session()

LANGS = ['JavaScript', 'TypeScript']
# Narrow slices so no query hits GitHub's 1,000-result cap (the script warns if one does).
STAR_SLICES = ([f'{a}..{a + 24}' for a in range(500, 1000, 25)] +
               ['1000..1099', '1100..1199', '1200..1349', '1350..1499', '1500..1749', '1750..1999',
                '2000..2499', '2500..2999', '3000..3999', '4000..4999', '5000..7499', '7500..9999',
                '10000..19999', '20000..39999', '>=40000'])
EXCLUDE = re.compile(r'vulnerable|goat|juice-shop|dvna|damn|ctf|exploit|insecure', re.I)

def search(q):
    out = []
    for page in range(1, 11):                      # search returns at most 1000 results per query
        r = API.get('https://api.github.com/search/repositories',
                    params={'q': q, 'sort': 'stars', 'order': 'desc', 'per_page': 100, 'page': page},
                    timeout=60)
        if r.status_code == 403 and 'rate limit' in r.text.lower():
            wait = int(r.headers.get('Retry-After', '60')); print('rate limited, waiting', wait); time.sleep(wait)
            continue
        r.raise_for_status()
        items = r.json().get('items', [])
        out += items
        time.sleep(2.2)                            # stay under 30 search requests per minute
        if len(items) < 100:
            break
    return out

def has_root_lock(full_name, branch):
    url = f'https://raw.githubusercontent.com/{full_name}/{branch}/package-lock.json'
    try:
        return RAW.head(url, timeout=30, allow_redirects=True).status_code == 200
    except requests.RequestException:
        return False

def main():
    seen = {}
    for lang in LANGS:
        for stars in STAR_SLICES:
            q = (f'language:{lang} stars:{stars} fork:false archived:false '
                 f'created:<2023-01-01 pushed:>2024-01-01')
            items = search(q)
            print(f'{lang} stars:{stars} -> {len(items)}' +
                  ('   WARNING: hit the 1000 cap, split this slice further' if len(items) >= 1000 else ''))
            for it in items:
                if not EXCLUDE.search(it['full_name']):
                    seen[it['full_name']] = it
    print(f'{len(seen)} unique repositories; checking for a root package-lock.json ...')
    rows = []
    for i, (name, it) in enumerate(seen.items(), 1):
        if has_root_lock(name, it['default_branch']):
            rows.append([name, it['default_branch'], '', it['stargazers_count'], it['language'],
                         it['created_at'][:10]])
        if i % 200 == 0:
            print(f'  {i}/{len(seen)} checked, {len(rows)} with lockfile')
    with open('candidates.csv', 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['repo', 'branch', 'lockfileVersion', 'stars', 'language', 'created'])
        w.writerows(rows)
    print(f'done: {len(rows)} repositories with a root package-lock.json -> candidates.csv')

if __name__ == '__main__':
    main()
