"""Where does VulnUp beat the strongest baseline? Paired comparison per project and budget."""
import csv, sys, statistics as st
from collections import defaultdict
from scipy.stats import wilcoxon

f = sys.argv[1] if len(sys.argv) > 1 else 'results/2024-01-01/eval_d0.1_epss.csv'
rows = list(csv.DictReader(open(f)))
by = defaultdict(dict)
for r in rows:
    by[(r['repo'], int(r['budget']))][r['method']] = r
greedies = ['Severity-first greedy', 'EPSS-first greedy', 'Per-advisory (Dependabot-style)', 'Latest within budget']

def bucket(n):
    n = int(n); return '1' if n <= 1 else '2-5' if n <= 5 else '6+'

for B in (1, 3, 5, 10):
    keys = [k for k in by if k[1] == B]
    print(f'\nbudget {B}  ({len(keys)} projects)')
    for g in greedies:
        diff = [float(by[k][g]['risk']) - float(by[k]['VulnUp (CDK)']['risk']) for k in keys]
        rel = [d / float(by[k]['VulnUp (CDK)']['risk_ref']) for d, k in zip(diff, keys)]
        better = sum(d > 1e-12 for d in diff); worse = sum(d < -1e-12 for d in diff)
        nz = [d for d in diff if abs(d) > 1e-12]
        p = wilcoxon(nz).pvalue if len(nz) > 10 else float('nan')
        print(f'  vs {g:32s} VulnUp better on {better:3d}, worse on {worse}, tie {len(keys) - better - worse:3d};'
              f' mean extra risk removed {st.mean(rel):6.1%} of ref; Wilcoxon p={p:.1e}')
    # by size of the largest coupled component (decision deps)
    grp = defaultdict(list)
    for k in keys:
        c = by[k]['VulnUp (CDK)']
        best_g = min(float(by[k][g]['risk']) for g in greedies)
        grp[bucket(c['largest_component'])].append((best_g - float(c['risk'])) / float(c['risk_ref']))
    for b in ('1', '2-5', '6+'):
        if grp[b]:
            v = grp[b]
            print(f'    largest component {b:>3}: {len(v):3d} projects, beats best baseline on {sum(x > 1e-12 for x in v):3d},'
                  f' mean gain over best baseline {st.mean(v):6.1%} of ref risk, max {max(v):6.1%}')
