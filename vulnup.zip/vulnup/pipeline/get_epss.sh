#!/bin/sh
# Download EPSS scores for the 1st of every month, Jan 2024 - Jul 2026 (31 files, ~30 MB total).
# Run on your own computer:   sh get_epss.sh
# Then zip the epss_monthly folder and attach it in the chat.
mkdir -p epss_monthly
for y in 2024 2025 2026; do
  for m in 01 02 03 04 05 06 07 08 09 10 11 12; do
    d="$y-$m-01"
    [ "$y$m" -gt 202607 ] && break
    f="epss_monthly/epss_scores-$d.csv.gz"
    [ -s "$f" ] && continue
    curl -sSfL -o "$f" "https://epss.empiricalsecurity.com/epss_scores-$d.csv.gz" \
      || curl -sSfL -o "$f" "https://epss.cyentia.com/epss_scores-$d.csv.gz" \
      || { echo "FAILED $d"; rm -f "$f"; }
  done
done
ls epss_monthly | wc -l | xargs echo "files downloaded (expect 31):"
