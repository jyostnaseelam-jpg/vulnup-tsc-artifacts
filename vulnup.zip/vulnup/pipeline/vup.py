"""VUP: risk-optimal dependency upgrade planning. Model, exact solver and baselines.

Instance = one JSON from build_instances.py. A plan x picks one option index per
decision dependency (index 0 = the refreshed current version, cost 0).

  risk(x) = sum_u w_u * [u in A(i, x_i) for some i]
  cost(x) = sum_i c_i(x_i)

Solver CDK (component-decomposed knapsack):
  1. coupling graph on dependencies (linked when an advisory can be carried by both);
  2. per component, the (cost, risk) Pareto frontier: enumeration if small, else CP-SAT
     at every budget level;
  3. multiple-choice knapsack DP over components.
"""
import itertools, math
from collections import defaultdict

# ------------------------------------------------------------------ weights and costs
DEFAULT = {'delta_dev': 0.1, 'epss_fallback': None, 'use_epss': True,
           'cost_minor': 1, 'cost_major': 3}

def weights(inst, cfg=DEFAULT):
    eps = [a['epss'] for a in inst['advisories'].values() if a['epss'] is not None]
    fb = cfg['epss_fallback'] if cfg['epss_fallback'] is not None else (sorted(eps)[len(eps) // 2] if eps else 0.01)
    w = {}
    for u, a in inst['advisories'].items():
        p = (a['epss'] if a['epss'] is not None else fb) if cfg['use_epss'] else 1.0
        s = max(a['severity'], 1) / 4.0
        e = 1.0 if a['prod'] else cfg['delta_dev']
        w[u] = p * s * e
    return w

def option_cost(opt, cfg=DEFAULT):
    """Cost of moving to a non-reference option: 1 unit, plus cost_major per major version crossed."""
    if opt['d_major'] > 0:
        return cfg['cost_minor'] + cfg['cost_major'] * opt['d_major']
    return cfg['cost_minor']

def prepare(inst, cfg=DEFAULT):
    """Return deps: list of (name, [(cost, frozenset(advisories), option dict)]), and weights."""
    w = weights(inst, cfg)
    deps = []
    for d in inst['decision_deps']:
        opts = []
        for k, o in enumerate(d['options']):
            o = dict(o, is_ref=(k == 0))
            c = 0 if k == 0 else option_cost(o, cfg)
            opts.append((c, frozenset(o['advisories']), o))
        deps.append((d['name'], opts))
    return deps, w

def risk_of(deps, w, x, idx=None):
    present = set()
    for j, (name, opts) in enumerate(deps) if idx is None else ((j, deps[j]) for j in idx):
        present |= opts[x[j]][1]
    return sum(w[u] for u in present)

def cost_of(deps, x):
    return sum(deps[j][1][x[j]][0] for j in range(len(deps)))

# ------------------------------------------------------------------ decomposition
def components(deps):
    parent = list(range(len(deps)))
    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]; a = parent[a]
        return a
    owner = {}
    for j, (_, opts) in enumerate(deps):
        for _, A, _ in opts:
            for u in A:
                if u in owner:
                    parent[find(j)] = find(owner[u])
                else:
                    owner[u] = j
    comps = defaultdict(list)
    for j in range(len(deps)):
        comps[find(j)].append(j)
    return list(comps.values())

def pareto(points):
    """points: list of (cost, risk, choice). Keep strictly improving risk as cost grows."""
    pts = sorted(points, key=lambda p: (p[0], p[1]))
    out, best = [], math.inf
    for c, r, ch in pts:
        if r < best - 1e-12:
            out.append((c, r, ch)); best = r
    return out

def frontier_enum(deps, w, comp):
    pts = []
    for combo in itertools.product(*[range(len(deps[j][1])) for j in comp]):
        x = dict(zip(comp, combo))
        present = set()
        c = 0
        for j in comp:
            c += deps[j][1][x[j]][0]; present |= deps[j][1][x[j]][1]
        pts.append((c, sum(w[u] for u in present), x))
    return pareto(pts)

def solve_cpsat(deps, w, comp, budget, time_limit=10.0):
    from ortools.sat.python import cp_model
    SCALE = 10**6
    m = cp_model.CpModel()
    y = {(j, k): m.NewBoolVar(f'y{j}_{k}') for j in comp for k in range(len(deps[j][1]))}
    for j in comp:
        m.AddExactlyOne(y[j, k] for k in range(len(deps[j][1])))
    m.Add(sum(deps[j][1][k][0] * y[j, k] for j in comp for k in range(len(deps[j][1]))) <= budget)
    us = sorted({u for j in comp for _, A, _ in deps[j][1] for u in A})
    z = {}
    for u in us:                      # z_u = 1 if u present: present if any chosen option carries it
        z[u] = m.NewBoolVar(f'z_{u}')
        for j in comp:
            for k, (_, A, _) in enumerate(deps[j][1]):
                if u in A:
                    m.AddImplication(y[j, k], z[u])
    m.Minimize(sum(int(round(w[u] * SCALE)) * z[u] for u in us))
    s = cp_model.CpSolver(); s.parameters.max_time_in_seconds = time_limit; s.parameters.num_workers = 4
    st = s.Solve(m)
    if st not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None
    x = {j: next(k for k in range(len(deps[j][1])) if s.Value(y[j, k])) for j in comp}
    return x, st == cp_model.OPTIMAL

def frontier_ilp(deps, w, comp, B):
    pts, all_opt = [], True
    max_c = sum(max(o[0] for o in deps[j][1]) for j in comp)
    for b in range(0, min(B, max_c) + 1):
        r = solve_cpsat(deps, w, comp, b)
        if r is None:
            continue
        x, opt = r; all_opt &= opt
        pts.append((sum(deps[j][1][x[j]][0] for j in comp), risk_of(deps, w, x, comp), x))
    return pareto(pts), all_opt

ENUM_LIMIT = 50000

def solve_cdk(deps, w, B):
    """Exact (up to CP-SAT time limits) budgeted plan. Returns (x, info)."""
    comps = components(deps)
    fronts, info = [], {'components': len(comps), 'largest': max((len(c) for c in comps), default=0),
                        'ilp_components': 0, 'all_optimal': True}
    for comp in comps:
        size = math.prod(len(deps[j][1]) for j in comp)
        if size <= ENUM_LIMIT:
            fronts.append(frontier_enum(deps, w, comp))
        else:
            f, opt = frontier_ilp(deps, w, comp, B)
            info['ilp_components'] += 1; info['all_optimal'] &= opt
            fronts.append(f)
    # multiple-choice knapsack DP over components
    INF = math.inf
    dp = [0.0] * (B + 1)            # dp[b] = min risk over components so far with total cost <= b
    picks = [[] for _ in range(B + 1)]
    for f in fronts:
        nd, npk = [INF] * (B + 1), [None] * (B + 1)
        for b in range(B + 1):
            for c, r, x in f:
                if c <= b and dp[b - c] + r < nd[b]:
                    nd[b] = dp[b - c] + r; npk[b] = picks[b - c] + [x]
        dp, picks = nd, npk
    xs = {}
    for part in picks[B]:
        xs.update(part)
    x = [xs.get(j, 0) for j in range(len(deps))]
    return x, info

# ------------------------------------------------------------------ baselines
def refresh_only(deps, w, B):
    return [0] * len(deps)

def latest_everything(deps, w, B=None):
    """Newest option for every decision dependency (ignores the budget)."""
    return [max(range(len(o)), key=lambda k: (o[k][2]['d_major'], o[k][2]['d_minor'] or 0, k)) for _, o in deps]

def _greedy(deps, w, B, order):
    x, spent = [0] * len(deps), 0
    for u in order:
        cur = set().union(*(deps[j][1][x[j]][1] for j in range(len(deps))))
        if u not in cur:
            continue
        # cheapest option per carrier that drops u (never downgrade relative to the current pick's cost)
        change, extra = {}, 0
        for j, (_, opts) in enumerate(deps):
            if u in opts[x[j]][1]:
                cands = [(c, k) for k, (c, A, _) in enumerate(opts) if u not in A]
                if not cands:
                    change = None; break
                c, k = min(cands)
                change[j] = k; extra += max(0, c - opts[x[j]][0])
        if change is None or spent + extra > B:
            continue
        for j, k in change.items():
            x[j] = k
        spent = cost_of(deps, x)
    return x

def severity_first(deps, w, B, inst):
    order = sorted(inst['advisories'], key=lambda u: (-inst['advisories'][u]['severity'], u))
    return _greedy(deps, w, B, order)

def epss_first(deps, w, B, inst):
    order = sorted(inst['advisories'], key=lambda u: (-(inst['advisories'][u]['epss'] or 0), u))
    return _greedy(deps, w, B, order)

def risk_first(deps, w, B, inst):
    """Fixed-order greedy that ranks advisories by their full weight (EPSS x severity x exposure)."""
    order = sorted(inst['advisories'], key=lambda u: (-w.get(u, 0), u))
    return _greedy(deps, w, B, order)

def ratio_greedy(deps, w, B):
    """Cost-aware greedy: repeatedly apply the single option change with the best risk removed per unit of
    added cost that still fits the budget (zero-cost improvements first)."""
    x = [0] * len(deps); spent = 0
    while True:
        base = risk_of(deps, w, x); best = None
        for j, (_, opts) in enumerate(deps):
            for k in range(len(opts)):
                if k == x[j]:
                    continue
                dc = opts[k][0] - opts[x[j]][0]
                if spent + dc > B:
                    continue
                y = list(x); y[j] = k
                gain = base - risk_of(deps, w, y)
                if gain <= 1e-15:
                    continue
                score = gain / dc if dc > 0 else float('inf')
                if best is None or score > best[0]:
                    best = (score, j, k, dc)
        if best is None:
            return x
        _, j, k, dc = best; x[j] = k; spent += dc

def per_advisory(deps, w, B, inst, published):
    """Dependabot-style: oldest advisory first, minimal fix each, until the budget runs out."""
    order = sorted(inst['advisories'], key=lambda u: (published.get(u, ''), u))
    return _greedy(deps, w, B, order)

def latest_within_budget(deps, w, B):
    """Upgrade whole dependencies to their newest option, highest current risk first."""
    x, spent = [0] * len(deps), 0
    lat = latest_everything(deps, w)
    order = sorted(range(len(deps)), key=lambda j: -sum(w[u] for u in deps[j][1][0][1]))
    for j in order:
        c = deps[j][1][lat[j]][0]
        if spent + c <= B:
            x[j] = lat[j]; spent += c
    return x

def exact_ilp(deps, w, B, time_limit=30.0):
    r = solve_cpsat(deps, w, list(range(len(deps))), B, time_limit)
    if r is None:
        return [0] * len(deps), False
    return [r[0][j] for j in range(len(deps))], r[1]
