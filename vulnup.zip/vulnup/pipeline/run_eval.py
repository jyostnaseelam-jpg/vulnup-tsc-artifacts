"""Compare VulnUp (CDK) with baselines on built instances at several budgets.

usage: python pipeline/run_eval.py <date> [delta_dev] [use_epss 0/1]
output: results/<date>/eval_<tag>.csv (one row per project x budget x method) and a printed summary
"""
import csv, glob, json, os, sys, time, statistics as st
sys.path.insert(0, os.path.dirname(__file__))
import vup
from vulndb import AdvisoryIndex

DATE = sys.argv[1] if len(sys.argv) > 1 else '2024-01-01'
cfg = dict(vup.DEFAULT)
if len(sys.argv) > 2: cfg['delta_dev'] = float(sys.argv[2])
if len(sys.argv) > 3: cfg['use_epss'] = sys.argv[3] == '1'
if os.environ.get('COST_MAJOR'): cfg['cost_major'] = int(os.environ['COST_MAJOR'])
TAG = f"d{cfg['delta_dev']}_{'epss' if cfg['use_epss'] else 'sev'}_g{cfg['cost_major']}"
BUDGETS = [1, 3, 5, 10]
published = {a['id']: a['published'] for lst in AdvisoryIndex().idx.values() for a in lst}

ADDON = os.environ.get('ADDON') == '1'
EPSS_DATE = os.environ.get('EPSS_DATE')
EPSS_W = None
if EPSS_DATE:
    from world import World
    EPSS_W = World(EPSS_DATE); TAG += '_epss' + EPSS_DATE
rows = []
files = sorted(glob.glob(os.path.join('instances', DATE, '*.json')))
files = [f for f in files if not os.path.basename(f).startswith('_')]
for f in files:
    inst = json.load(open(f))
    if EPSS_W is not None:
        for u, a in inst['advisories'].items():
            a['epss'] = EPSS_W.epss_of(u)
    deps, w = vup.prepare(inst, cfg)
    if not deps:
        continue
    r0 = vup.risk_of(deps, w, [0] * len(deps))
    if r0 <= 0:
        continue
    big = sum(max(o[0] for o in opts) for _, opts in deps)
    xmax, _ = vup.solve_cdk(deps, w, big)
    rmin = vup.risk_of(deps, w, xmax)
    lat = vup.latest_everything(deps, w)
    base = {'repo': inst['repo'], 'decision_deps': len(deps), 'risk_ref': r0, 'risk_min_unbudgeted': rmin,
            'latest_all_cost': vup.cost_of(deps, lat), 'latest_all_risk': vup.risk_of(deps, w, lat)}
    for B in BUDGETS:
        methods = {}
        if ADDON:
            methods['Risk-first greedy'] = (vup.risk_first(deps, w, B, inst), 0)
            methods['Ratio greedy'] = (vup.ratio_greedy(deps, w, B), 0)
            info = {}
        else:
          t = time.time(); x, info = vup.solve_cdk(deps, w, B); methods['VulnUp (CDK)'] = (x, time.time() - t)
          t = time.time(); xi, opt = vup.exact_ilp(deps, w, B); methods['Exact ILP'] = (xi, time.time() - t)
          methods['Refresh only'] = (vup.refresh_only(deps, w, B), 0)
          methods['Latest within budget'] = (vup.latest_within_budget(deps, w, B), 0)
          methods['Severity-first greedy'] = (vup.severity_first(deps, w, B, inst), 0)
          methods['EPSS-first greedy'] = (vup.epss_first(deps, w, B, inst), 0)
          methods['Per-advisory (Dependabot-style)'] = (vup.per_advisory(deps, w, B, inst, published), 0)
        for m, (x, secs) in methods.items():
            r = vup.risk_of(deps, w, x)
            rows.append(dict(base, budget=B, method=m, risk=r, cost=vup.cost_of(deps, x),
                             removed_share=(r0 - r) / r0,
                             removed_of_removable=((r0 - r) / (r0 - rmin)) if r0 - rmin > 1e-15 else None,
                             majors=sum(deps[j][1][x[j]][2]['d_major'] > 0 for j in range(len(deps))),
                             seconds=round(secs, 4),
                             components=info['components'] if m == 'VulnUp (CDK)' else '',
                             largest_component=info['largest'] if m == 'VulnUp (CDK)' else '',
                             ilp_optimal=opt if m == 'Exact ILP' else ''))


out = os.path.join('results', DATE, f'eval_{TAG}.csv')
if ADDON:   # merge the extra baselines into the existing results file
    new = {r['method'] for r in rows}
    old = [r for r in csv.DictReader(open(out)) if r['method'] not in new]
    fields = list(old[0].keys())
    rows = old + [{k: r.get(k, '') for k in fields} for r in rows]
with open(out, 'w', newline='') as fh:
    wr = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wr.writeheader(); wr.writerows(rows)

if ADDON:
    sys.exit(0)
projects = len({r['repo'] for r in rows})
print(f'{projects} projects with removable-or-not risk, config {TAG}')
for B in BUDGETS:
    print(f'\nbudget {B}:')
    for m in dict.fromkeys(r['method'] for r in rows):
        sel = [r for r in rows if r['budget'] == B and r['method'] == m]
        rem = [r['removed_of_removable'] for r in sel if r['removed_of_removable'] is not None]
        print(f"  {m:34s} mean risk removed {st.mean(r['removed_share'] for r in sel):6.1%}"
              f"   of removable {st.mean(rem):6.1%}   mean cost {st.mean(r['cost'] for r in sel):5.2f}"
              f"   max secs {max(r['seconds'] for r in sel):.2f}")
