#!/bin/sh
# Final 30-month replays with dated EPSS. Log: data/replay_grid.log
for S in 1 2 3 4 5 6 7 8; do for M in clustered random; do
  [ $M = random ] && [ $S -gt 6 ] && continue
  f=results/replay/${M}_L3_n25_s${S}_b0.25.csv; [ -f $f ] && continue
  echo "== START $M seed=$S"
  python3 pipeline/replay.py 25 $S 0.25 30 $M 2>&1 | grep -E "cumulative|Traceback|Error"
done; done
echo REPLAY_DONE
