"""Mean share of removable risk removed vs budget (0..16) over single-service instances, EPSS of 2024-01-01."""
import glob, json, os, sys, statistics as st
sys.path.insert(0, os.path.dirname(__file__))
import vup
from world import World
from vulndb import AdvisoryIndex
W = World('2024-01-01')
published = {a['id']: a['published'] for lst in AdvisoryIndex().idx.values() for a in lst}
BUD = list(range(0, 17))
res = {m: {b: [] for b in BUD} for m in ('VulnUp', 'EPSS-first', 'Severity-first', 'Per-advisory', 'Risk-first', 'Ratio greedy')}
for f in sorted(glob.glob('instances/2024-01-01/*.json')):
    if os.path.basename(f).startswith('_'): continue
    inst = json.load(open(f))
    for u, a in inst['advisories'].items(): a['epss'] = W.epss_of(u)
    deps, w = vup.prepare(inst)
    if not deps: continue
    r0 = vup.risk_of(deps, w, [0] * len(deps))
    big = sum(max(o[0] for o in opts) for _, opts in deps)
    rmin = vup.risk_of(deps, w, vup.solve_cdk(deps, w, big)[0])
    if r0 - rmin <= 1e-15: continue
    for b in BUD:
        plans = {'VulnUp': vup.solve_cdk(deps, w, b)[0], 'EPSS-first': vup.epss_first(deps, w, b, inst),
                 'Severity-first': vup.severity_first(deps, w, b, inst), 'Per-advisory': vup.per_advisory(deps, w, b, inst, published), 'Risk-first': vup.risk_first(deps, w, b, inst), 'Ratio greedy': vup.ratio_greedy(deps, w, b)}
        for m, x in plans.items():
            res[m][b].append((r0 - vup.risk_of(deps, w, x)) / (r0 - rmin))
out = {m: [round(100 * st.mean(res[m][b]), 1) for b in BUD] for m in res}
out['n'] = len(res['VulnUp'][0])
json.dump(out, open('results/2024-01-01/budget_curve.json', 'w'))
print(out)
