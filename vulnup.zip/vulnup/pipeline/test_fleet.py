"""Check the fleet CP-SAT model against exhaustive search on tiny random fleets."""
import itertools, random, sys, os
sys.path.insert(0, os.path.dirname(__file__))
import fleet

def rand_fleet(rng, n_svc, pkgs):
    F = fleet.Fleet([], fcfg=dict(fleet.FCFG))
    advs = [f'A{i}' for i in range(5)]
    for p in range(n_svc):
        sv = []
        for j in range(rng.randint(1, 2)):
            pkg = rng.choice(pkgs)
            opts = [{'A': frozenset(rng.sample(advs, rng.randint(1, 3))), 'local': 0, 'bounds': (), 'd_major': 0}]
            for k in range(1, rng.randint(2, 3)):
                dm = rng.choice([0, 1, 2])
                A = frozenset(a for a in opts[0]['A'] if rng.random() < 0.4)
                opts.append({'A': A, 'local': 1 + dm, 'bounds': tuple((pkg, b) for b in range(dm)), 'd_major': dm})
            sv.append(opts)
        F.svc.append(sv); F.w.append({a: rng.random() for a in advs})
    F.deps = [(p, j) for p in range(len(F.svc)) for j in range(len(F.svc[p]))]
    return F

def brute(F, T, B):
    choices = []
    for (p, j) in F.deps:
        choices.append([None] + [(k, t) for k in range(1, len(F.svc[p][j])) for t in range(1, T + 1)])
    best = float('inf')
    for combo in itertools.product(*choices):
        plan = {d: c for d, c in zip(F.deps, combo) if c}
        e, _, ok = F.evaluate(plan, T, B)
        if ok and e < best:
            best = e
    return best

rng = random.Random(3); n = bad = 0
for trial in range(120):
    F = rand_fleet(rng, rng.randint(1, 3), ['P', 'Q'])
    for T, B in ((1, 3), (2, 3), (2, 6), (3, 4)):
        opt = brute(F, T, B)
        plan, info = F.solve(T, B, time_limit=10, workers=2)
        e, _, ok = F.evaluate(plan, T, B)
        n += 1
        if not ok or abs(e - opt) > 1e-4 * max(1, opt):
            bad += 1; print('MISMATCH', trial, T, B, opt, e, ok)
        # baselines must be feasible
        for pl in (F.advisory_order_greedy(T, B, key=lambda pa: -F.w[pa[0]][pa[1]]), F.ratio_greedy(T, B),
                   F.ratio_greedy(T, B, waves=True), F.myopic_sprint_optimal(T, B, 5)):
            e2, _, ok2 = F.evaluate(pl, T, B)
            if not ok2 or e2 < opt - 1e-6:
                bad += 1; print('BASELINE INVALID', trial, T, B, e2, opt, ok2)
print(f'{n} checks, {bad} problems')
