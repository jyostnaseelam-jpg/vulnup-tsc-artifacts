"""Summary of the final replays: synthetic fleets (results/replay_v2) and real organisation fleets (results/replay_org).

For each fleet and method: reduction of cumulative exposure relative to Refresh only, for
  plan  : exposure with EPSS as published each month (what planners saw),
  hind  : exposure with each CVE's peak EPSS over Jan 2024 - Jul 2026 (hindsight; never seen by planners),
  kev   : exposure to advisories CISA lists as known exploited (severity x exposure weight),
and the same split before / after the EPSS v4 switch (first monthly file using v4: 2025-04-01).
Paired comparisons: VulnUp-Fleet (look-ahead 3) minus each baseline; exact Wilcoxon; bootstrap 95% CI of the mean.
"""
import csv, glob, json, random, statistics as st, sys
from collections import defaultdict
from scipy.stats import wilcoxon
MAIN = 'VulnUp-Fleet (look-ahead 3)'
V4 = '2025-04-01'

def load(f):
    tot = defaultdict(lambda: defaultdict(float)); n = 0
    for r in csv.DictReader(open(f)):
        m = r['method']
        for key, col in (('plan', 'exposure'), ('hind', 'exposure_hindsight'), ('kev', 'exposure_kev')):
            v = float(r[col]); tot[m][key] += v
            tot[m][key + ('_pre' if r['month'] < V4 else '_post')] += v
        n = int(r['fleet_size'])
    red = {}
    for m in tot:
        red[m] = {k: ((tot['Refresh only'][k] - tot[m][k]) / tot['Refresh only'][k]) if tot['Refresh only'][k] > 0 else None
                  for k in tot[m]}
    return {'file': f.split('/')[-1], 'n': n, 'red': red, 'ref': dict(tot['Refresh only'])}

def boot(d, B=10000, seed=1):
    rng = random.Random(seed); ms = sorted(st.mean(rng.choices(d, k=len(d))) for _ in range(B))
    return ms[int(0.025 * B)], ms[int(0.975 * B)]

def report(runs, label, keys=('plan', 'hind', 'kev', 'plan_pre', 'plan_post')):
    out = {'label': label, 'fleets': len(runs)}
    print(f'\n== {label}: {len(runs)} fleets')
    methods = list(runs[0]['red'])
    for key in keys:
        sel = [r for r in runs if r['red'][MAIN].get(key) is not None]
        if not sel:
            print(f'  [{key}] no fleet has exposure'); continue
        print(f'  [{key}] {len(sel)} fleets with exposure')
        out[key] = {'fleets': len(sel), 'mean': {}, 'gain': {}}
        for m in methods:
            v = [r['red'][m][key] for r in sel]; out[key]['mean'][m] = st.mean(v)
            print(f'     {m:30s} mean reduction {st.mean(v):6.1%}')
        for m in methods:
            if m in (MAIN, 'Refresh only'):
                continue
            d = [r['red'][MAIN][key] - r['red'][m][key] for r in sel]
            nz = [x for x in d if abs(x) > 1e-12]
            p = wilcoxon(nz, method='exact').pvalue if len(nz) >= 5 else float('nan')
            lo, hi = boot(d)
            better = sum(x > 1e-12 for x in d); worse = sum(x < -1e-12 for x in d)
            out[key]['gain'][m] = dict(mean=st.mean(d), lo=lo, hi=hi, better=better, worse=worse, p=p, n=len(d))
            print(f'     vs {m:28s} {st.mean(d):+6.2%} [{lo:+.2%},{hi:+.2%}] better {better} worse {worse} p={p:.3g}')
    return out

res = {}
syn = [load(f) for f in sorted(glob.glob('results/replay_v2/*_n25_*_b0.25.csv'))]
org = [load(f) for f in sorted(glob.glob('results/replay_org/org-*.csv'))]
# org fleets in which planning could change anything (some exposure and some method differs from refresh)
org_act = [r for r in org if any(abs(r['red'][m]['plan'] or 0) > 1e-9 for m in r['red'] if m != 'Refresh only')]
print('org fleets:', len(org), 'with any effect:', len(org_act), 'sizes', sorted(r['n'] for r in org))
for lab, runs in (('stack-similar', [r for r in syn if r['file'].startswith('clustered')]),
                  ('random', [r for r in syn if r['file'].startswith('random')]), ('all synthetic', syn),
                  ('real organisations (all)', org), ('real organisations (with effect)', org_act)):
    if runs:
        res[lab] = report(runs, lab)
json.dump(res, open('results/replay_summary2.json', 'w'), indent=1, default=str)
for r in org:
    print(f"  {r['file']:45s} n={r['n']:2d} VU {r['red'][MAIN]['plan'] or 0:6.1%} EPSS {r['red']['EPSS-first greedy']['plan'] or 0:6.1%} "
          f"Risk {r['red']['Risk-first greedy']['plan'] or 0:6.1%} greedy {r['red']['Fleet-aware greedy']['plan'] or 0:6.1%}")
