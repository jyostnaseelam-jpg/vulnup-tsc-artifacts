# VulnUp — data pipeline and feasibility check

Pipeline for *risk-optimal dependency upgrade planning* on npm projects, built only on public data.

## Setup

```bash
pip install semver node-semver requests
git clone --depth 1 --filter=blob:none --sparse https://github.com/github/advisory-database.git data/adb
(cd data/adb && git sparse-checkout set advisories/github-reviewed)
curl -o data/kev.json https://raw.githubusercontent.com/cisagov/kev-data/main/known_exploited_vulnerabilities.json
# EPSS (not yet used in the first run; download it yourself):
#   current scores: https://epss.empiricalsecurity.com/epss_scores-current.csv.gz  -> data/epss.csv.gz
#   for historical replay, download the daily file for each snapshot date
```

## Run

```bash
python pipeline/find_repos.py                        # (on your machine, needs GITHUB_TOKEN) -> candidates.csv
python pipeline/snapshot_multi.py data/candidates_gh.csv 2024-01-01,2026-07-01   # lockfiles at each date
# pilot only: probe_repos.py + snapshot_lockfiles.py on 54 hand-picked repos (results in results_pilot/)
python pipeline/build_advisories.py                  # npm advisories + KEV (+ EPSS if present) -> data/npm_advisories.json
python pipeline/analyze_snapshot.py 2024-01-01       # classify vulnerable nodes -> results/<date>/
python pipeline/report_stats.py 2024-01-01           # derived numbers
python pipeline/carrier_components.py 2024-01-01     # size of jointly-coupled subproblems
```

## Files

| File | Purpose |
| --- | --- |
| `pipeline/lockgraph.py` | Parses package-lock v1/v2/v3 into a resolved graph (Node module resolution, workspaces, links) |
| `pipeline/vulndb.py` | OSV range matching; npm registry release times (cached in `data/registry/`) |
| `pipeline/analyze_snapshot.py` | Per vulnerable node: advisories, severity, KEV, dev/prod, fix class, direct-dependency carriers |
| `results/2024-01-01/` | Output of the first run: `nodes.csv`, `projects.csv`, `summary.json`, `derived.json`, `components.json` |

## Fix classes

- **refresh** — an unaffected version released by the date satisfies every dependent's range (lockfile refresh fixes it).
- **needs-upgrade** — a fix exists but outside some dependent's range; a parent, ultimately a direct dependency, must change.
- **no-fix** — no unaffected version at or above the installed one had been released by the date.

## Known limitations of this first run

- Corpus: 4,314 GitHub repos (>=500 stars, JS/TS, root package-lock.json); popular open source, not enterprise code.
- The first search hit GitHub's 1,000-result cap in some star ranges; find_repos.py now uses narrower slices.
- `OWASP/NodeGoat` is excluded because it is deliberately vulnerable.
- Advisories come from today's database filtered by publish date; advisories edited after the date may differ slightly from what was visible then.
- EPSS is today's file (12 Oct 2026), so snapshot-date analyses have look-ahead bias until dated files are used.
- "Carriers" are computed on the installed graph; whether a newer direct-dependency version actually removes the node is not yet resolved (next step).

## Single-project and fleet experiments

```bash
python pipeline/build_instances.py 2024-01-01 500     # resolve candidate versions from npm -> instances/<date>/
python pipeline/test_vup.py                           # single-project solver vs brute force
python pipeline/run_eval.py 2024-01-01 0.1 1          # single-project VulnUp vs baselines
python pipeline/test_fleet.py                         # fleet solver vs brute force
./pipeline/fleet_grid.sh                              # fleet grid (random / stack-similar, L=3/8, n=10/25/50)
python pipeline/fleet_summary.py                      # summary + Wilcoxon tests
```

## Revision (October 2026)
- New baselines: Risk-first (ranks by full weight w = EPSS x severity x exposure) and a single-service ratio greedy
  (`vup.risk_first`, `vup.ratio_greedy`); added to existing results with `ADDON=1` in run_eval.py / run_fleet.py.
- Replay records hindsight exposure (peak EPSS Jan 2024-Jul 2026) and KEV exposure (`pipeline/hindsight.py`, needs data/kev.csv).
- Organization fleets: `python pipeline/replay.py 0 1 0.25 30 org-<owner>` (all repos of one owner); `BUDGET=6` fixes the monthly budget.
- Summaries: `pipeline/replay_monthly.py '<glob>' [exposure|exposure_hindsight]` (month-normalized metric, robust to the
  EPSS v4 rescaling in April 2025) and `pipeline/replay_summary2.py` (raw cumulative, pre/post EPSS v4, KEV).
- Results: results/replay_v2 (synthetic), results/replay_org (proportional budget), results/replay_org6 (budget 6),
  results/replay_term (terminal-weight ablation).
